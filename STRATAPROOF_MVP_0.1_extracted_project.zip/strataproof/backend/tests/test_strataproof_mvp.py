from datetime import date
from uuid import UUID
from app.core.enums import (
    ClaimClassification,
    PetroleumSystemElementType,
    ReviewStatus,
    SourceQualityTier,
)
from app.models.knowledge import BasinProfile, FormationRecord
from app.models.operational import Well, WellInterval


def _auth_headers(token: str, org_id: str) -> dict:
    return {"Authorization": f"Bearer {token}", "X-Organisation-ID": org_id}


def test_end_to_end_tenant_isolation_knowledge_gating_validation_falsification_and_pdf(client, db_session, monkeypatch):
    # 1. Register Tenant A and Tenant B
    reg_a = client.post(
        "/api/v1/auth/register",
        json={
            "email": "lead.a@nigerdelta-energy.ng",
            "full_name": "Dr. Chinedu Eze, CGeol",
            "password": "StrongPassword123!",
            "organisation_name": "Niger Delta Assurance Energy Ltd",
            "country": "Nigeria",
        },
    )
    assert reg_a.status_code == 201
    tok_a = reg_a.json()

    reg_b = client.post(
        "/api/v1/auth/register",
        json={
            "email": "lead.b@rival-basin.ng",
            "full_name": "Engr. Zainab Musa",
            "password": "StrongPassword123!",
            "organisation_name": "Rival Basin Exploration Plc",
            "country": "Nigeria",
        },
    )
    assert reg_b.status_code == 201
    tok_b = reg_b.json()

    headers_a = _auth_headers(tok_a["access_token"], tok_a["organisation_id"])
    headers_b = _auth_headers(tok_b["access_token"], tok_b["organisation_id"])

    # 2. Seed formation rank order for Niger Delta Basin (1 = youngest Benin, 2 = Agbada, 3 = oldest Akata)
    nd_basin = db_session.query(BasinProfile).filter(BasinProfile.basin_name == "Niger Delta Basin").first()
    assert nd_basin is not None
    db_session.add_all(
        [
            FormationRecord(
                basin_profile_id=nd_basin.id,
                formation_name="Benin Formation",
                stratigraphic_rank_order=1,
                age_range="Oligocene-Recent",
                review_status=ReviewStatus.APPROVED,
            ),
            FormationRecord(
                basin_profile_id=nd_basin.id,
                formation_name="Agbada Formation",
                stratigraphic_rank_order=2,
                age_range="Eocene-Pliocene",
                review_status=ReviewStatus.APPROVED,
            ),
            FormationRecord(
                basin_profile_id=nd_basin.id,
                formation_name="Akata Formation",
                stratigraphic_rank_order=3,
                age_range="Paleocene-Recent",
                review_status=ReviewStatus.APPROVED,
            ),
        ]
    )
    db_session.commit()

    # 3. Create Project & Prospect in Tenant A
    proj_res = client.post(
        "/api/v1/projects",
        headers=headers_a,
        json={"name": "OML-99 Deep Assurance", "code": "OML99", "country": "Nigeria"},
    )
    assert proj_res.status_code == 201
    project_id = proj_res.json()["id"]

    prosp_res = client.post(
        "/api/v1/prospects",
        headers=headers_a,
        json={
            "project_id": project_id,
            "name": "Kolo-Deep Prospect",
            "country": "Nigeria",
            "basin_name": "Niger Delta Basin",
            "target_formations": ["Agbada Formation"],
        },
    )
    assert prosp_res.status_code == 201
    prospect_id = prosp_res.json()["id"]

    # 4. Verify Cross-Tenant Isolation: Tenant B cannot access Tenant A's prospect or forge X-Organisation-ID
    cross_get = client.get(f"/api/v1/prospects/{prospect_id}", headers=headers_b)
    assert cross_get.status_code == 404

    forged_headers = _auth_headers(tok_b["access_token"], tok_a["organisation_id"])
    forged_get = client.get(f"/api/v1/prospects/{prospect_id}", headers=forged_headers)
    assert forged_get.status_code == 403

    # 5. Knowledge Library Gating: register an UNREVIEWED/QUARANTINED claim vs an APPROVED claim
    src_res = client.post(
        "/api/v1/admin/knowledge/sources",
        headers=headers_a,
        json={
            "title": "Petroleum Geology of the Niger Delta",
            "authors_or_institution": "Doust, H. & Omatsola, E.",
            "publication_type": "AAPG Memoir 48",
            "publication_year": 1990,
            "access_date": str(date.today()),
            "country": "Nigeria",
            "basin_or_area": "Niger Delta Basin",
            "geological_subject": "Regional Stratigraphy & Growth Fault Seals",
            "source_quality_tier": SourceQualityTier.TIER_B_PEER_REVIEWED_OFFICIAL.value,
        },
    )
    assert src_res.status_code == 201
    source_id = src_res.json()["id"]

    kc_approved = client.post(
        "/api/v1/admin/knowledge/claims",
        headers=headers_a,
        json={
            "claim_text": "Overpressured marine Akata shales form the primary regional source rock and detachment horizon in the Niger Delta.",
            "subject": "Source Rock & Detachment",
            "geological_discipline": "Petroleum Systems",
            "country": "Nigeria",
            "basin": "Niger Delta Basin",
            "formation": "Akata Formation",
            "claim_classification": ClaimClassification.INTERPRETATION.value,
            "source_quality_tier": SourceQualityTier.TIER_B_PEER_REVIEWED_OFFICIAL.value,
            "limitations": "Deep ultra-offshore TOC calibration remains sparse.",
            "applicability_scope": "Niger Delta depobelts",
            "source_ids": [source_id],
        },
    )
    assert kc_approved.status_code == 201
    kc_id = kc_approved.json()["id"]

    rev_kc = client.post(
        f"/api/v1/admin/knowledge/claims/{kc_id}/review",
        headers=headers_a,
        json={"decision": ReviewStatus.APPROVED.value, "review_rationale": "Verified against AAPG Memoir 48."},
    )
    assert rev_kc.status_code == 200

    # Quarantined unverified claim must NEVER be retrieved into RAG
    kc_quar = client.post(
        "/api/v1/admin/knowledge/claims",
        headers=headers_a,
        json={
            "claim_text": "UNVERIFIED RUMOR: Giant continuous tar mat seals entire basin.",
            "subject": "Seal",
            "geological_discipline": "Structural Geology",
            "country": "Nigeria",
            "basin": "Niger Delta Basin",
            "claim_classification": ClaimClassification.ASSUMPTION.value,
            "source_quality_tier": SourceQualityTier.QUARANTINED_UNVERIFIED.value,
            "limitations": "Unverified blog claim.",
            "applicability_scope": "Unverified",
            "source_ids": [source_id],
        },
    )
    assert kc_quar.status_code == 201

    from app.services.ai.rag import retrieve_verified_basin_knowledge

    rag_hits = retrieve_verified_basin_knowledge(db_session, country="Nigeria", basin_name="Niger Delta Basin")
    assert any("Akata shales" in h.claim_text for h in rag_hits)
    assert all("UNVERIFIED RUMOR" not in h.claim_text for h in rag_hits)

    # 6. Inject stratigraphic inversion & mixed depth units in Well Kolo-1 to verify deterministic rules
    well = Well(
        organisation_id=UUID(tok_a["organisation_id"]),
        prospect_id=UUID(prospect_id),
        well_identifier="KOLO-1",
    )
    db_session.add(well)
    db_session.flush()
    db_session.add_all(
        [
            WellInterval(
                organisation_id=UUID(tok_a["organisation_id"]),
                well_id=well.id,
                formation_name="Akata Formation",
                top_depth=1800.0,
                bottom_depth=2200.0,
                depth_unit="m",
                depth_datum="KB",
            ),
            WellInterval(
                organisation_id=UUID(tok_a["organisation_id"]),
                well_id=well.id,
                formation_name="Benin Formation",
                top_depth=2300.0,
                bottom_depth=7500.0,
                depth_unit="ft",
                depth_datum="MSL",
            ),
        ]
    )
    db_session.commit()

    # 7. Register an unsupported geological claim in Evidence Ledger
    cl_res = client.post(
        "/api/v1/claims",
        headers=headers_a,
        json={
            "prospect_id": prospect_id,
            "geological_element": "Fault Seal Capacity",
            "petroleum_system_element": PetroleumSystemElementType.SEAL.value,
            "claim_text": "Bounding growth fault provides lateral seal across 250 m hydrocarbon column.",
            "claim_classification": ClaimClassification.ASSUMPTION.value,
        },
    )
    assert cl_res.status_code == 201

    # 8. Execute Deterministic Validation & Falsification Engine
    val_res = client.post(f"/api/v1/prospects/{prospect_id}/validate", headers=headers_a)
    assert val_res.status_code == 200

    ct_res = client.get(f"/api/v1/prospects/{prospect_id}/contradictions", headers=headers_a)
    assert ct_res.status_code == 200
    categories = {c["category"] for c in ct_res.json()}
    assert "STRATIGRAPHIC_ORDER_CONTRADICTION" in categories
    assert "DEPTH_UNIT_DATUM_INCONSISTENCY" in categories
    assert "UNSUPPORTED_CLAIM_OR_ASSUMPTION" in categories

    fal_res = client.post(f"/api/v1/prospects/{prospect_id}/falsify", headers=headers_a)
    assert fal_res.status_code == 200

    ps_res = client.get(f"/api/v1/prospects/{prospect_id}/petroleum-system", headers=headers_a)
    assert len(ps_res.json()) == 8

    inv_res = client.get(f"/api/v1/prospects/{prospect_id}/investigations", headers=headers_a)
    assert len(inv_res.json()) == 8
    assert inv_res.json()[0]["priority_rank"] == 1

    # 9. Mock S3 put/presign and generate 20-section PDF report
    from app.services.storage import PrivateObjectStorageService

    monkeypatch.setattr(
        PrivateObjectStorageService,
        "__init__",
        lambda self: setattr(self, "client", type("MockS3", (), {"put_object": lambda *a, **kw: None})()),
    )
    monkeypatch.setattr(
        PrivateObjectStorageService,
        "generate_presigned_download_url",
        lambda self, **kw: "https://minio.local/presigned-report.pdf",
    )

    pdf_res = client.post(f"/api/v1/prospects/{prospect_id}/assessments", headers=headers_a, json={})
    assert pdf_res.status_code == 201
    assert len(pdf_res.json()["pdf_sha256"]) == 64
