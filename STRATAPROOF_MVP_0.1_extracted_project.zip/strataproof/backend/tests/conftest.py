import os
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

os.environ["DATABASE_URL"] = "sqlite:///./test_strataproof.db"
os.environ["AI_PROVIDER"] = "disabled"

from app.core.database import get_db
from app.main import app
from app.models.operational import Base
import app.models.knowledge  # noqa: F401
from app.services.knowledge.nigerian_seed import seed_nigerian_knowledge_taxonomy

TEST_ENGINE = create_engine("sqlite:///./test_strataproof.db", connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=TEST_ENGINE)


@pytest.fixture(scope="session", autouse=True)
def setup_test_database():
    Base.metadata.drop_all(bind=TEST_ENGINE)
    Base.metadata.create_all(bind=TEST_ENGINE)
    db = TestingSessionLocal()
    try:
        seed_nigerian_knowledge_taxonomy(db)
    finally:
        db.close()
    yield
    Base.metadata.drop_all(bind=TEST_ENGINE)
    if os.path.exists("./test_strataproof.db"):
        os.remove("./test_strataproof.db")


@pytest.fixture()
def db_session():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture()
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()
