"""Initial STRATAPROOF MVP 0.1 schema and PostgreSQL Row-Level Security (RLS)

Revision ID: 0001_initial_schema
Revises:
Create Date: 2026-11-16
"""
from alembic import op
from app.models.operational import Base
import app.models.knowledge  # noqa: F401

revision = "0001_initial_schema"
down_revision = None
branch_labels = None
depends_on = None

TENANT_SCOPED_TABLES = [
    "organisation_memberships",
    "audit_events",
    "projects",
    "prospects",
    "wells",
    "prospect_wells",
    "well_intervals",
    "documents",
    "document_versions",
    "document_sections",
    "source_locations",
    "ingestion_jobs",
    "extracted_records",
    "geological_claims",
    "claim_revisions",
    "evidence_items",
    "claim_evidence",
    "claim_reviews",
    "analysis_runs",
    "contradictions",
    "contradiction_resolutions",
    "petroleum_system_elements",
    "falsification_hypotheses",
    "hypothesis_evidence",
    "investigations",
    "investigation_rankings",
    "assessments",
    "assessment_versions",
    "assessment_references",
]


def upgrade() -> None:
    bind = op.get_bind()
    Base.metadata.create_all(bind=bind)

    if bind.dialect.name == "postgresql":
        op.execute('CREATE EXTENSION IF NOT EXISTS "vector";')
        for table in TENANT_SCOPED_TABLES:
            op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;")
            op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;")
            op.execute(
                f"""
                CREATE POLICY tenant_isolation_{table} ON {table}
                USING (
                    current_setting('app.current_organisation_id', true) IS NULL
                    OR current_setting('app.current_organisation_id', true) = ''
                    OR organisation_id::text = current_setting('app.current_organisation_id', true)
                )
                WITH CHECK (
                    current_setting('app.current_organisation_id', true) IS NULL
                    OR current_setting('app.current_organisation_id', true) = ''
                    OR organisation_id::text = current_setting('app.current_organisation_id', true)
                );
                """
            )


def downgrade() -> None:
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for table in TENANT_SCOPED_TABLES:
            op.execute(f"DROP POLICY IF EXISTS tenant_isolation_{table} ON {table};")
    Base.metadata.drop_all(bind=bind)
