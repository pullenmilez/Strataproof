from datetime import datetime, timezone
from uuid import UUID
from celery import Celery

from app.core.config import settings
from app.core.database import SessionLocal
from app.core.enums import ProcessingStatus, ReviewStatus
from app.models.operational import (
    Document,
    DocumentSection,
    DocumentVersion,
    ExtractedRecord,
    IngestionJob,
    SourceLocation,
    Well,
    WellInterval,
)
from app.services.ingestion.las_parser import parse_las_bytes
from app.services.ingestion.pdf_parser import parse_pdf_document
from app.services.ingestion.tabular_parser import parse_csv_bytes, parse_xlsx_bytes
from app.services.storage import PrivateObjectStorageService

celery_app = Celery("strataproof_worker", broker=settings.REDIS_URL, backend=settings.REDIS_URL)


def _try_float(val) -> float | None:
    if val is None:
        return None
    try:
        return float(str(val).strip())
    except (ValueError, TypeError):
        return None


def execute_extraction_job(job_id: UUID) -> None:
    db = SessionLocal()
    storage = PrivateObjectStorageService()
    try:
        job = db.query(IngestionJob).filter(IngestionJob.id == job_id).first()
        if not job:
            return

        job.status = ProcessingStatus.PROCESSING
        db.commit()

        doc_ver = db.query(DocumentVersion).filter(DocumentVersion.id == job.document_version_id).first()
        doc = db.query(Document).filter(Document.id == doc_ver.document_id).first()
        raw_bytes = storage.download_bytes(bucket=doc_ver.s3_bucket, object_key=doc_ver.s3_object_key)
        fname = doc_ver.original_filename.lower()
        warnings: list[str] = []

        if fname.endswith(".pdf"):
            parsed = parse_pdf_document(raw_bytes)
            warnings.extend(parsed.warnings)
            for page in parsed.pages:
                db.add(
                    DocumentSection(
                        organisation_id=doc.organisation_id,
                        document_version_id=doc_ver.id,
                        section_heading=f"Page {page.page_number}",
                        page_start=page.page_number,
                        page_end=page.page_number,
                        extracted_text=page.text,
                    )
                )
                loc = SourceLocation(
                    organisation_id=doc.organisation_id,
                    document_version_id=doc_ver.id,
                    page_number=page.page_number,
                    section_or_sheet=f"Page {page.page_number}",
                    verbatim_excerpt=page.text[:1500],
                )
                db.add(loc)
                db.flush()
                db.add(
                    ExtractedRecord(
                        organisation_id=doc.organisation_id,
                        prospect_id=doc.prospect_id,
                        document_version_id=doc_ver.id,
                        source_location_id=loc.id,
                        record_type="PDF_PAGE_TEXT",
                        raw_payload={"page_number": page.page_number, "char_count": len(page.text)},
                        extraction_method="pytesseract_ocr" if page.used_ocr else "pypdf_text",
                        extraction_quality_label="REQUIRES_HUMAN_CHECK" if page.used_ocr else "DETERMINISTIC_DIRECT",
                        review_status=ReviewStatus.UNREVIEWED,
                    )
                )

        elif fname.endswith(".csv") or fname.endswith(".xlsx"):
            parsed = parse_csv_bytes(raw_bytes) if fname.endswith(".csv") else parse_xlsx_bytes(raw_bytes)
            warnings.extend(parsed.warnings)
            for row in parsed.rows:
                loc = SourceLocation(
                    organisation_id=doc.organisation_id,
                    document_version_id=doc_ver.id,
                    section_or_sheet=row.sheet_name,
                    row_or_line_reference=f"Row {row.row_number}",
                    verbatim_excerpt=str(row.raw_dict)[:1500],
                )
                db.add(loc)
                db.flush()

                needs_check = row.has_missing_units or row.has_missing_well_id
                db.add(
                    ExtractedRecord(
                        organisation_id=doc.organisation_id,
                        prospect_id=doc.prospect_id,
                        document_version_id=doc_ver.id,
                        source_location_id=loc.id,
                        record_type="TABULAR_ROW",
                        raw_payload=row.raw_dict,
                        extraction_method="csv_parser" if fname.endswith(".csv") else "openpyxl_parser",
                        extraction_quality_label="REQUIRES_HUMAN_CHECK" if needs_check else "DETERMINISTIC_DIRECT",
                        review_status=ReviewStatus.UNREVIEWED,
                    )
                )

                well_id_str = (
                    row.raw_dict.get("well_identifier")
                    or row.raw_dict.get("well_name")
                    or row.raw_dict.get("well")
                )
                fm_name = row.raw_dict.get("formation_name") or row.raw_dict.get("formation")
                if well_id_str and fm_name:
                    well = (
                        db.query(Well)
                        .filter(
                            Well.organisation_id == doc.organisation_id,
                            Well.prospect_id == doc.prospect_id,
                            Well.well_identifier == str(well_id_str).strip(),
                        )
                        .first()
                    )
                    if not well:
                        well = Well(
                            organisation_id=doc.organisation_id,
                            prospect_id=doc.prospect_id,
                            well_identifier=str(well_id_str).strip(),
                            depth_unit=row.raw_dict.get("depth_unit") or row.raw_dict.get("unit"),
                            depth_datum=row.raw_dict.get("depth_datum") or row.raw_dict.get("datum"),
                        )
                        db.add(well)
                        db.flush()

                    db.add(
                        WellInterval(
                            organisation_id=doc.organisation_id,
                            well_id=well.id,
                            formation_name=str(fm_name).strip(),
                            top_depth=_try_float(row.raw_dict.get("top_depth") or row.raw_dict.get("top")),
                            bottom_depth=_try_float(row.raw_dict.get("bottom_depth") or row.raw_dict.get("bottom")),
                            depth_type=(row.raw_dict.get("depth_type") or "MD").strip(),
                            depth_unit=row.raw_dict.get("depth_unit") or row.raw_dict.get("unit"),
                            depth_datum=row.raw_dict.get("depth_datum") or row.raw_dict.get("datum"),
                            reported_age=row.raw_dict.get("age") or row.raw_dict.get("reported_age"),
                            lithology_summary=row.raw_dict.get("lithology"),
                            source_location_id=loc.id,
                        )
                    )

        elif fname.endswith(".las"):
            parsed = parse_las_bytes(raw_bytes)
            warnings.extend(parsed.warnings)
            loc = SourceLocation(
                organisation_id=doc.organisation_id,
                document_version_id=doc_ver.id,
                section_or_sheet="~Well / ~Curve",
                verbatim_excerpt=str(parsed.well_header)[:1500],
            )
            db.add(loc)
            db.flush()
            db.add(
                ExtractedRecord(
                    organisation_id=doc.organisation_id,
                    prospect_id=doc.prospect_id,
                    document_version_id=doc_ver.id,
                    source_location_id=loc.id,
                    record_type="LAS_WELL_LOG_HEADER",
                    raw_payload={
                        "well_header": parsed.well_header,
                        "curves": parsed.curves,
                        "depth_start": parsed.depth_start,
                        "depth_stop": parsed.depth_stop,
                        "depth_unit": parsed.depth_unit,
                    },
                    extraction_method="lasio_parser",
                    extraction_quality_label="REQUIRES_HUMAN_CHECK" if warnings else "DETERMINISTIC_DIRECT",
                    review_status=ReviewStatus.UNREVIEWED,
                )
            )

        job.extraction_warnings = warnings
        job.status = ProcessingStatus.COMPLETED_WITH_WARNINGS if warnings else ProcessingStatus.COMPLETED
        job.completed_at = datetime.now(timezone.utc)
        db.commit()
    except Exception as exc:
        db.rollback()
        job = db.query(IngestionJob).filter(IngestionJob.id == job_id).first()
        if job:
            job.status = ProcessingStatus.FAILED
            job.error_message = f"Extraction failed ({type(exc).__name__})."
            job.completed_at = datetime.now(timezone.utc)
            db.commit()
    finally:
        db.close()


@celery_app.task(name="strataproof.process_document_version")
def process_document_version_task(job_id_str: str) -> None:
    execute_extraction_job(UUID(job_id_str))
