import uuid
from datetime import datetime, timezone
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Enum as SAEnum,
    Float,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, relationship

from app.core.enums import (
    ClaimClassification,
    ContradictionOutcome,
    PetroleumSystemElementType,
    ProcessingStatus,
    QualitativeStatus,
    ReviewStatus,
    SeverityLevel,
    UserRole,
)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class TimestampMixin:
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at = Column(DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False)
    deleted_at = Column(DateTime(timezone=True), nullable=True)


# ---------------------------------------------------------------------------
# 1. MULTI-TENANT ORGANISATION, USERS, RBAC & AUDIT
# ---------------------------------------------------------------------------


class Organisation(Base, TimestampMixin):
    __tablename__ = "organisations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    slug = Column(String(120), unique=True, nullable=False, index=True)
    country = Column(String(120), nullable=False, default="Nigeria")
    ai_processing_authorized = Column(Boolean, nullable=False, default=False)
    is_active = Column(Boolean, nullable=False, default=True)


class User(Base, TimestampMixin):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    full_name = Column(String(255), nullable=False)
    password_hash = Column(String(512), nullable=False)
    professional_credentials = Column(String(255), nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)


class OrganisationMembership(Base, TimestampMixin):
    __tablename__ = "organisation_memberships"
    __table_args__ = (UniqueConstraint("organisation_id", "user_id", name="uq_org_user"),)

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    role = Column(SAEnum(UserRole, name="user_role_enum"), nullable=False, default=UserRole.GEOSCIENTIST)
    is_default = Column(Boolean, nullable=False, default=True)


class RolePermission(Base):
    __tablename__ = "role_permissions"
    __table_args__ = (UniqueConstraint("role", "permission_code", name="uq_role_perm"),)

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    role = Column(SAEnum(UserRole, name="user_role_enum"), nullable=False)
    permission_code = Column(String(120), nullable=False)
    description = Column(String(255), nullable=True)


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="SET NULL"), nullable=True, index=True)
    actor_user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    event_type = Column(String(120), nullable=False, index=True)
    entity_type = Column(String(120), nullable=False)
    entity_id = Column(String(120), nullable=False)
    event_metadata = Column(JSON, nullable=False, default=dict)
    occurred_at = Column(DateTime(timezone=True), default=utcnow, nullable=False, index=True)


# ---------------------------------------------------------------------------
# 2. PROJECTS, PROSPECTS, WELLS & STRATIGRAPHIC INTERVALS
# ---------------------------------------------------------------------------


class Project(Base, TimestampMixin):
    __tablename__ = "projects"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    code = Column(String(80), nullable=False)
    country = Column(String(120), nullable=False, default="Nigeria")
    description = Column(Text, nullable=True)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)


class Prospect(Base, TimestampMixin):
    __tablename__ = "prospects"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    block_or_licence = Column(String(120), nullable=True)
    country = Column(String(120), nullable=False, default="Nigeria")
    basin_name = Column(String(150), nullable=False, index=True)
    sub_basin_or_province = Column(String(150), nullable=True)
    basin_profile_id = Column(UUID(as_uuid=True), ForeignKey("basin_profiles.id", ondelete="SET NULL"), nullable=True)
    target_formations = Column(JSON, nullable=False, default=list)
    description = Column(Text, nullable=True)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)


class Well(Base, TimestampMixin):
    __tablename__ = "wells"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False, index=True)
    well_identifier = Column(String(150), nullable=False, index=True)
    well_alias = Column(String(150), nullable=True)
    spud_date = Column(String(40), nullable=True)
    total_depth_raw = Column(Float, nullable=True)
    depth_unit = Column(String(30), nullable=True)
    depth_datum = Column(String(60), nullable=True)
    coordinate_system = Column(String(120), nullable=True)
    surface_x_raw = Column(Float, nullable=True)
    surface_y_raw = Column(Float, nullable=True)


class ProspectWell(Base):
    __tablename__ = "prospect_wells"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False)
    well_id = Column(UUID(as_uuid=True), ForeignKey("wells.id", ondelete="CASCADE"), nullable=False)
    role_in_prospect = Column(String(80), nullable=False, default="OFFSET_WELL")


class WellInterval(Base, TimestampMixin):
    __tablename__ = "well_intervals"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    well_id = Column(UUID(as_uuid=True), ForeignKey("wells.id", ondelete="CASCADE"), nullable=False, index=True)
    formation_name = Column(String(150), nullable=False, index=True)
    top_depth = Column(Float, nullable=True)
    bottom_depth = Column(Float, nullable=True)
    depth_type = Column(String(30), nullable=True)   # MD, TVD, TVDSS
    depth_unit = Column(String(20), nullable=True)   # m, ft
    depth_datum = Column(String(60), nullable=True)  # KB, MSL, GL
    reported_age = Column(String(120), nullable=True)
    lithology_summary = Column(Text, nullable=True)
    source_location_id = Column(UUID(as_uuid=True), ForeignKey("source_locations.id", ondelete="SET NULL"), nullable=True)


# ---------------------------------------------------------------------------
# 3. DOCUMENTS, VERSIONS, SOURCE LOCATIONS & INGESTION
# ---------------------------------------------------------------------------


class Document(Base, TimestampMixin):
    __tablename__ = "documents"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    document_type = Column(String(80), nullable=False)
    current_version = Column(Integer, nullable=False, default=1)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)

    versions = relationship("DocumentVersion", back_populates="document", cascade="all, delete-orphan")


class DocumentVersion(Base, TimestampMixin):
    __tablename__ = "document_versions"
    __table_args__ = (UniqueConstraint("document_id", "version_number", name="uq_doc_ver"),)

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    document_id = Column(UUID(as_uuid=True), ForeignKey("documents.id", ondelete="CASCADE"), nullable=False, index=True)
    version_number = Column(Integer, nullable=False, default=1)
    original_filename = Column(String(255), nullable=False)
    mime_type = Column(String(120), nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    sha256_checksum = Column(String(64), nullable=False, index=True)
    s3_bucket = Column(String(120), nullable=False)
    s3_object_key = Column(String(512), nullable=False, unique=True)
    uploaded_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)

    document = relationship("Document", back_populates="versions")


class DocumentSection(Base):
    __tablename__ = "document_sections"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    document_version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id", ondelete="CASCADE"), nullable=False, index=True)
    section_heading = Column(String(255), nullable=True)
    page_start = Column(Integer, nullable=True)
    page_end = Column(Integer, nullable=True)
    extracted_text = Column(Text, nullable=False)


class SourceLocation(Base):
    __tablename__ = "source_locations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    document_version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id", ondelete="CASCADE"), nullable=False, index=True)
    page_number = Column(Integer, nullable=True)
    section_or_sheet = Column(String(255), nullable=True)
    row_or_line_reference = Column(String(120), nullable=True)
    verbatim_excerpt = Column(Text, nullable=False)


class IngestionJob(Base, TimestampMixin):
    __tablename__ = "ingestion_jobs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    document_version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id", ondelete="CASCADE"), nullable=False, index=True)
    celery_task_id = Column(String(120), nullable=True)
    status = Column(SAEnum(ProcessingStatus, name="processing_status_enum"), nullable=False, default=ProcessingStatus.PENDING)
    extraction_warnings = Column(JSON, nullable=False, default=list)
    error_message = Column(Text, nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)


class ExtractedRecord(Base, TimestampMixin):
    __tablename__ = "extracted_records"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False, index=True)
    document_version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id", ondelete="CASCADE"), nullable=False)
    source_location_id = Column(UUID(as_uuid=True), ForeignKey("source_locations.id", ondelete="SET NULL"), nullable=True)
    record_type = Column(String(80), nullable=False)
    raw_payload = Column(JSON, nullable=False)
    extraction_method = Column(String(80), nullable=False)
    extraction_quality_label = Column(String(60), nullable=False, default="DETERMINISTIC_DIRECT")
    review_status = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False, default=ReviewStatus.UNREVIEWED)


# ---------------------------------------------------------------------------
# 4. GEOLOGICAL EVIDENCE LEDGER (CLAIMS, REVISIONS, EVIDENCE & REVIEWS)
# ---------------------------------------------------------------------------


class GeologicalClaim(Base, TimestampMixin):
    __tablename__ = "geological_claims"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False, index=True)
    geological_element = Column(String(120), nullable=False)
    petroleum_system_element = Column(SAEnum(PetroleumSystemElementType, name="ps_element_enum"), nullable=True)
    claim_text = Column(Text, nullable=False)
    claim_classification = Column(SAEnum(ClaimClassification, name="claim_class_enum"), nullable=False)
    stratigraphic_applicability = Column(String(255), nullable=True)
    spatial_applicability = Column(String(255), nullable=True)
    conditions_and_limitations = Column(Text, nullable=True)
    qualitative_status = Column(SAEnum(QualitativeStatus, name="qual_status_enum"), nullable=False, default=QualitativeStatus.INSUFFICIENT_EVIDENCE)
    review_status = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False, default=ReviewStatus.UNREVIEWED)
    is_ai_suggested = Column(Boolean, nullable=False, default=False)
    current_revision = Column(Integer, nullable=False, default=1)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)

    evidence_links = relationship("ClaimEvidence", back_populates="claim", cascade="all, delete-orphan")


class ClaimRevision(Base):
    __tablename__ = "claim_revisions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    claim_id = Column(UUID(as_uuid=True), ForeignKey("geological_claims.id", ondelete="CASCADE"), nullable=False, index=True)
    revision_number = Column(Integer, nullable=False)
    claim_text = Column(Text, nullable=False)
    claim_classification = Column(SAEnum(ClaimClassification, name="claim_class_enum"), nullable=False)
    conditions_and_limitations = Column(Text, nullable=True)
    change_reason = Column(Text, nullable=False)
    revised_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    revised_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)


class EvidenceItem(Base, TimestampMixin):
    __tablename__ = "evidence_items"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False, index=True)
    document_version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id", ondelete="SET NULL"), nullable=True)
    source_location_id = Column(UUID(as_uuid=True), ForeignKey("source_locations.id", ondelete="SET NULL"), nullable=True)
    evidence_type = Column(String(120), nullable=False)
    geological_subject = Column(String(150), nullable=False)
    evidence_description = Column(Text, nullable=False)
    well_identifier = Column(String(150), nullable=True)
    formation = Column(String(150), nullable=True)
    depth_interval_raw = Column(String(120), nullable=True)
    depth_unit = Column(String(30), nullable=True)
    evidence_strength_note = Column(Text, nullable=True)
    review_status = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False, default=ReviewStatus.UNREVIEWED)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)


class ClaimEvidence(Base):
    __tablename__ = "claim_evidence"
    __table_args__ = (UniqueConstraint("claim_id", "evidence_id", name="uq_claim_ev"),)

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    claim_id = Column(UUID(as_uuid=True), ForeignKey("geological_claims.id", ondelete="CASCADE"), nullable=False)
    evidence_id = Column(UUID(as_uuid=True), ForeignKey("evidence_items.id", ondelete="CASCADE"), nullable=False)
    relationship_role = Column(String(40), nullable=False, default="SUPPORTING")
    rationale = Column(Text, nullable=True)
    linked_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    linked_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)

    claim = relationship("GeologicalClaim", back_populates="evidence_links")


class ClaimReview(Base):
    __tablename__ = "claim_reviews"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    claim_id = Column(UUID(as_uuid=True), ForeignKey("geological_claims.id", ondelete="CASCADE"), nullable=False, index=True)
    reviewer_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    decision = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False)
    reviewer_notes = Column(Text, nullable=False)
    reviewed_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)


# ---------------------------------------------------------------------------
# 5. DETERMINISTIC RULE ENGINE & CONTRADICTIONS
# ---------------------------------------------------------------------------


class GeologicalRule(Base, TimestampMixin):
    __tablename__ = "geological_rules"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_code = Column(String(80), unique=True, nullable=False)
    category = Column(String(120), nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    is_active = Column(Boolean, nullable=False, default=True)


class RuleVersion(Base):
    __tablename__ = "rule_versions"
    __table_args__ = (UniqueConstraint("rule_id", "version_tag", name="uq_rule_ver"),)

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_id = Column(UUID(as_uuid=True), ForeignKey("geological_rules.id", ondelete="CASCADE"), nullable=False)
    version_tag = Column(String(40), nullable=False)
    implementation_ref = Column(String(255), nullable=False)
    parameters_schema = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)


class AnalysisRun(Base):
    __tablename__ = "analysis_runs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False, index=True)
    run_type = Column(String(80), nullable=False)
    triggered_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    executed_rule_versions = Column(JSON, nullable=False, default=list)
    ai_model_used = Column(String(120), nullable=True)
    status = Column(SAEnum(ProcessingStatus, name="processing_status_enum"), nullable=False, default=ProcessingStatus.COMPLETED)
    started_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)
    completed_at = Column(DateTime(timezone=True), nullable=True)


class Contradiction(Base, TimestampMixin):
    __tablename__ = "contradictions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False, index=True)
    analysis_run_id = Column(UUID(as_uuid=True), ForeignKey("analysis_runs.id", ondelete="CASCADE"), nullable=False)
    rule_version_id = Column(UUID(as_uuid=True), ForeignKey("rule_versions.id"), nullable=False)
    category = Column(String(120), nullable=False)
    outcome_classification = Column(SAEnum(ContradictionOutcome, name="contradiction_outcome_enum"), nullable=False)
    severity = Column(SAEnum(SeverityLevel, name="severity_level_enum"), nullable=False)
    well_or_interval = Column(String(255), nullable=True)
    first_source_location_id = Column(UUID(as_uuid=True), ForeignKey("source_locations.id", ondelete="SET NULL"), nullable=True)
    second_source_location_id = Column(UUID(as_uuid=True), ForeignKey("source_locations.id", ondelete="SET NULL"), nullable=True)
    affected_claim_ids = Column(JSON, nullable=False, default=list)
    first_value_raw = Column(String(255), nullable=False)
    second_value_raw = Column(String(255), nullable=False)
    units = Column(String(60), nullable=True)
    explanation = Column(Text, nullable=False)
    possible_geological_causes = Column(JSON, nullable=False, default=list)
    review_status = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False, default=ReviewStatus.UNREVIEWED)


class ContradictionResolution(Base):
    __tablename__ = "contradiction_resolutions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    contradiction_id = Column(UUID(as_uuid=True), ForeignKey("contradictions.id", ondelete="CASCADE"), nullable=False)
    reviewer_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    outcome_classification = Column(SAEnum(ContradictionOutcome, name="contradiction_outcome_enum"), nullable=False)
    resolution_notes = Column(Text, nullable=False)
    resolved_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)


# ---------------------------------------------------------------------------
# 6. PETROLEUM SYSTEM FALSIFICATION, INVESTIGATIONS & ASSESSMENTS
# ---------------------------------------------------------------------------


class PetroleumSystemElement(Base, TimestampMixin):
    __tablename__ = "petroleum_system_elements"
    __table_args__ = (UniqueConstraint("prospect_id", "element_type", name="uq_prospect_ps_elem"),)

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False, index=True)
    element_type = Column(SAEnum(PetroleumSystemElementType, name="ps_element_enum"), nullable=False)
    qualitative_status = Column(SAEnum(QualitativeStatus, name="qual_status_enum"), nullable=False, default=QualitativeStatus.INSUFFICIENT_EVIDENCE)
    status_rationale = Column(Text, nullable=False)
    missing_evidence_summary = Column(JSON, nullable=False, default=list)
    review_status = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False, default=ReviewStatus.UNREVIEWED)


class FalsificationHypothesis(Base, TimestampMixin):
    __tablename__ = "falsification_hypotheses"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False, index=True)
    element_id = Column(UUID(as_uuid=True), ForeignKey("petroleum_system_elements.id", ondelete="CASCADE"), nullable=False)
    analysis_run_id = Column(UUID(as_uuid=True), ForeignKey("analysis_runs.id", ondelete="CASCADE"), nullable=False)
    proposed_failure_mechanism = Column(Text, nullable=False)
    geological_applicability = Column(String(255), nullable=False)
    relevance_conditions = Column(Text, nullable=False)
    missing_evidence = Column(JSON, nullable=False, default=list)
    knowledge_source_ids = Column(JSON, nullable=False, default=list)
    confidence_rationale = Column(Text, nullable=False)
    is_ai_suggested = Column(Boolean, nullable=False, default=True)
    review_status = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False, default=ReviewStatus.AI_SUGGESTED_PENDING_REVIEW)
    reviewed_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    reviewer_notes = Column(Text, nullable=True)


class HypothesisEvidence(Base):
    __tablename__ = "hypothesis_evidence"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    hypothesis_id = Column(UUID(as_uuid=True), ForeignKey("falsification_hypotheses.id", ondelete="CASCADE"), nullable=False)
    evidence_id = Column(UUID(as_uuid=True), ForeignKey("evidence_items.id", ondelete="CASCADE"), nullable=False)
    stance = Column(String(40), nullable=False)  # SUPPORTS_FAILURE | OPPOSES_FAILURE


class Investigation(Base, TimestampMixin):
    __tablename__ = "investigations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False, index=True)
    hypothesis_id = Column(UUID(as_uuid=True), ForeignKey("falsification_hypotheses.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(255), nullable=False)
    discriminating_objective = Column(Text, nullable=False)
    required_data_or_test = Column(Text, nullable=False)
    user_supplied_cost_estimate = Column(String(120), nullable=True)
    user_supplied_time_estimate = Column(String(120), nullable=True)
    technical_feasibility_note = Column(Text, nullable=False)


class InvestigationRanking(Base):
    __tablename__ = "investigation_rankings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    investigation_id = Column(UUID(as_uuid=True), ForeignKey("investigations.id", ondelete="CASCADE"), nullable=False, unique=True)
    priority_rank = Column(Integer, nullable=False)
    decision_relevance = Column(String(40), nullable=False)
    discrimination_power = Column(String(120), nullable=False)
    prioritisation_rationale = Column(Text, nullable=False)
    ranked_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)


class Assessment(Base, TimestampMixin):
    __tablename__ = "assessments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False)
    prospect_id = Column(UUID(as_uuid=True), ForeignKey("prospects.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(300), nullable=False)
    current_version = Column(Integer, nullable=False, default=1)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)


class AssessmentVersion(Base):
    __tablename__ = "assessment_versions"
    __table_args__ = (UniqueConstraint("assessment_id", "version_number", name="uq_assess_ver"),)

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    assessment_id = Column(UUID(as_uuid=True), ForeignKey("assessments.id", ondelete="CASCADE"), nullable=False)
    version_number = Column(Integer, nullable=False, default=1)
    scope_and_limitations = Column(Text, nullable=False)
    snapshot_data = Column(JSON, nullable=False)
    pdf_s3_key = Column(String(512), nullable=False)
    pdf_sha256 = Column(String(64), nullable=False)
    generated_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    generated_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)


class AssessmentReference(Base):
    __tablename__ = "assessment_references"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organisation_id = Column(UUID(as_uuid=True), ForeignKey("organisations.id", ondelete="CASCADE"), nullable=False, index=True)
    assessment_version_id = Column(UUID(as_uuid=True), ForeignKey("assessment_versions.id", ondelete="CASCADE"), nullable=False)
    reference_type = Column(String(40), nullable=False)  # CUSTOMER_DOCUMENT | VERIFIED_KNOWLEDGE_SOURCE
    document_version_id = Column(UUID(as_uuid=True), ForeignKey("document_versions.id", ondelete="SET NULL"), nullable=True)
    knowledge_source_id = Column(UUID(as_uuid=True), ForeignKey("knowledge_sources.id", ondelete="SET NULL"), nullable=True)
    citation_label = Column(String(500), nullable=False)
