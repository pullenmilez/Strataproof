import uuid
from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID

from app.core.enums import ClaimClassification, ReviewStatus, SourceQualityTier
from app.models.operational import Base, TimestampMixin, utcnow


# ---------------------------------------------------------------------------
# ENVIRONMENT B: CURATED & VERIFIED GEOLOGICAL KNOWLEDGE LIBRARY
# ---------------------------------------------------------------------------


class SourceLicence(Base, TimestampMixin):
    __tablename__ = "source_licences"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    licence_code = Column(String(80), unique=True, nullable=False)
    name = Column(String(200), nullable=False)
    permits_full_text_storage = Column(Boolean, nullable=False, default=False)
    permits_snippet_retrieval = Column(Boolean, nullable=False, default=True)
    attribution_requirements = Column(Text, nullable=False)


class KnowledgeSource(Base, TimestampMixin):
    __tablename__ = "knowledge_sources"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title = Column(String(500), nullable=False)
    authors_or_institution = Column(String(500), nullable=False)
    publication_type = Column(String(120), nullable=False)
    publisher_or_journal = Column(String(255), nullable=True)
    publication_year = Column(Integer, nullable=True)
    doi_or_identifier = Column(String(255), nullable=True)
    url = Column(String(500), nullable=True)
    access_date = Column(Date, nullable=False)
    country = Column(String(120), nullable=False, default="Nigeria", index=True)
    basin_or_area = Column(String(150), nullable=False, index=True)
    geological_subject = Column(String(150), nullable=False)
    licence_id = Column(UUID(as_uuid=True), ForeignKey("source_licences.id"), nullable=False)
    source_quality_tier = Column(SAEnum(SourceQualityTier, name="source_quality_tier_enum"), nullable=False)
    peer_review_status = Column(String(80), nullable=False)
    verification_status = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False, default=ReviewStatus.UNREVIEWED)
    s3_reference_key = Column(String(512), nullable=True)
    notes = Column(Text, nullable=True)


class GeologicalKnowledgeClaim(Base, TimestampMixin):
    __tablename__ = "geological_knowledge_claims"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    claim_text = Column(Text, nullable=False)
    subject = Column(String(150), nullable=False, index=True)
    geological_discipline = Column(String(120), nullable=False)
    country = Column(String(120), nullable=False, default="Nigeria", index=True)
    basin = Column(String(150), nullable=False, index=True)
    sub_basin_or_province = Column(String(150), nullable=True)
    formation = Column(String(150), nullable=True, index=True)
    age_interval = Column(String(120), nullable=True)
    claim_classification = Column(SAEnum(ClaimClassification, name="claim_class_enum"), nullable=False)
    source_quality_tier = Column(SAEnum(SourceQualityTier, name="source_quality_tier_enum"), nullable=False)
    review_status = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False, default=ReviewStatus.UNREVIEWED, index=True)
    limitations = Column(Text, nullable=False)
    applicability_scope = Column(Text, nullable=False)
    is_disputed = Column(Boolean, nullable=False, default=False)


class KnowledgeClaimSource(Base):
    __tablename__ = "knowledge_claim_sources"
    __table_args__ = (UniqueConstraint("knowledge_claim_id", "knowledge_source_id", name="uq_kclaim_src"),)

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    knowledge_claim_id = Column(UUID(as_uuid=True), ForeignKey("geological_knowledge_claims.id", ondelete="CASCADE"), nullable=False)
    knowledge_source_id = Column(UUID(as_uuid=True), ForeignKey("knowledge_sources.id", ondelete="CASCADE"), nullable=False)
    page_or_section_citation = Column(String(255), nullable=True)


class KnowledgeEmbedding(Base):
    __tablename__ = "knowledge_embeddings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    knowledge_claim_id = Column(UUID(as_uuid=True), ForeignKey("geological_knowledge_claims.id", ondelete="CASCADE"), nullable=False, unique=True)
    embedding_model = Column(String(120), nullable=False)
    vector_json = Column(JSON, nullable=True)
    created_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)


class KnowledgeConflict(Base, TimestampMixin):
    __tablename__ = "knowledge_conflicts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    country = Column(String(120), nullable=False, default="Nigeria")
    basin = Column(String(150), nullable=False, index=True)
    subject = Column(String(255), nullable=False)
    first_knowledge_claim_id = Column(UUID(as_uuid=True), ForeignKey("geological_knowledge_claims.id"), nullable=False)
    second_knowledge_claim_id = Column(UUID(as_uuid=True), ForeignKey("geological_knowledge_claims.id"), nullable=False)
    conflict_summary = Column(Text, nullable=False)
    geological_context_note = Column(Text, nullable=False)


class KnowledgeReview(Base):
    __tablename__ = "knowledge_reviews"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    knowledge_claim_id = Column(UUID(as_uuid=True), ForeignKey("geological_knowledge_claims.id", ondelete="CASCADE"), nullable=False)
    reviewer_user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    decision = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False)
    review_rationale = Column(Text, nullable=False)
    reviewed_at = Column(DateTime(timezone=True), default=utcnow, nullable=False)


class BasinProfile(Base, TimestampMixin):
    __tablename__ = "basin_profiles"
    __table_args__ = (UniqueConstraint("country", "basin_name", name="uq_country_basin"),)

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    country = Column(String(120), nullable=False, default="Nigeria")
    basin_name = Column(String(150), nullable=False)
    basin_category = Column(String(120), nullable=False)
    sub_basins_or_provinces = Column(JSON, nullable=False, default=list)
    tectonic_summary = Column(Text, nullable=False)
    stratigraphic_overview = Column(Text, nullable=False)
    known_uncertainties_and_gaps = Column(Text, nullable=False)
    review_status = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False, default=ReviewStatus.APPROVED)


class FormationRecord(Base, TimestampMixin):
    __tablename__ = "formation_records"
    __table_args__ = (UniqueConstraint("basin_profile_id", "formation_name", name="uq_basin_fm"),)

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    basin_profile_id = Column(UUID(as_uuid=True), ForeignKey("basin_profiles.id", ondelete="CASCADE"), nullable=False, index=True)
    formation_name = Column(String(150), nullable=False)
    recognized_aliases = Column(JSON, nullable=False, default=list)
    stratigraphic_rank_order = Column(Integer, nullable=True)  # 1 = youngest (top), N = oldest (base)
    age_range = Column(String(120), nullable=True)
    dominant_lithology = Column(Text, nullable=True)
    depositional_environment = Column(Text, nullable=True)
    petroleum_system_role = Column(String(120), nullable=True)
    review_status = Column(SAEnum(ReviewStatus, name="review_status_enum"), nullable=False, default=ReviewStatus.APPROVED)
