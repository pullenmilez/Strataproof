from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1 import (
    admin_knowledge,
    analysis,
    assessments,
    audit,
    auth,
    documents,
    evidence,
    projects,
)
from app.core.config import settings
from app.core.database import SessionLocal
from app.services.knowledge.nigerian_seed import seed_nigerian_knowledge_taxonomy


@asynccontextmanager
async def lifespan(app: FastAPI):
    db = SessionLocal()
    try:
        seed_nigerian_knowledge_taxonomy(db)
    except Exception:
        db.rollback()
    finally:
        db.close()
    yield


app = FastAPI(
    title="STRATAPROOF API — MVP 0.1",
    description="Petroleum Exploration Geological Evidence-Assurance & Falsification Platform",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

API_PREFIX = "/api/v1"
app.include_router(auth.router, prefix=API_PREFIX)
app.include_router(projects.router, prefix=API_PREFIX)
app.include_router(documents.router, prefix=API_PREFIX)
app.include_router(evidence.router, prefix=API_PREFIX)
app.include_router(admin_knowledge.router, prefix=API_PREFIX)
app.include_router(analysis.router, prefix=API_PREFIX)
app.include_router(assessments.router, prefix=API_PREFIX)
app.include_router(audit.router, prefix=API_PREFIX)


@app.get("/healthz")
def health_check():
    return {"status": "ok", "service": "strataproof-api", "version": "0.1.0"}
