from datetime import date, datetime
from uuid import UUID
from pydantic import BaseModel, Field
from app.core.enums import (
    ClaimClassification,
    PetroleumSystemElementType,
    QualitativeStatus,
    ReviewStatus,
    SourceQualityTier,
)


class ClaimCreate(BaseModel):
    prospect_id: UUID
    geological_element: str = Field(min_length=2, max_length=120)
    petroleum_system_element: PetroleumSystemElementType | None = None
    claim_text: str = Field(min_length=5)
    claim_classification: ClaimClassification
    stratigraphic_applicability: str | None = None
    spatial_applicability: str | None = None
    conditions_and_limitations: str | None = None
    is_ai_suggested: bool = False


class ClaimReviseRequest(BaseModel):
    claim_text: str = Field(min_length=5)
    claim_classification: ClaimClassification
    conditions_and_limitations: str | None = None
    change_reason: str = Field(min_length=5)


class ClaimReviewRequest(BaseModel):
    decision: ReviewStatus
    reviewer_notes: str = Field(min_length=5)
    qualitative_status: QualitativeStatus | None = None


class ClaimOut(BaseModel):
    id: UUID
    organisation_id: UUID
    prospect_id: UUID
    geological_element: str
    petroleum_system_element: PetroleumSystemElementType | None
    claim_text: str
    claim_classification: ClaimClassification
    stratigraphic_applicability: str | None
    spatial_applicability: str | None
    conditions_and_limitations: str | None
    qualitative_status: QualitativeStatus
    review_status: ReviewStatus
    is_ai_suggested: bool
    current_revision: int
    created_at: datetime

    model_config = {"from_attributes": True}


class EvidenceCreate(BaseModel):
    prospect_id: UUID
    document_version_id: UUID | None = None
    source_location_id: UUID | None = None
    evidence_type: str = Field(min_length=2, max_length=120)
    geological_subject: str = Field(min_length=2, max_length=150)
    evidence_description: str = Field(min_length=5)
    well_identifier: str | None = None
    formation: str | None = None
    depth_interval_raw: str | None = None
    depth_unit: str | None = None
    evidence_strength_note: str | None = None


class EvidenceOut(BaseModel):
    id: UUID
    prospect_id: UUID
    document_version_id: UUID | None
    source_location_id: UUID | None
    evidence_type: str
    geological_subject: str
    evidence_description: str
    well_identifier: str | None
    formation: str | None
    depth_interval_raw: str | None
    depth_unit: str | None
    review_status: ReviewStatus

    model_config = {"from_attributes": True}


class LinkClaimEvidenceRequest(BaseModel):
    evidence_id: UUID
    relationship_role: str = Field(default="SUPPORTING", pattern="^(SUPPORTING|OPPOSING|CONTEXTUAL)$")
    rationale: str | None = None


class KnowledgeSourceCreate(BaseModel):
    title: str = Field(min_length=3, max_length=500)
    authors_or_institution: str = Field(min_length=2, max_length=500)
    publication_type: str
    publisher_or_journal: str | None = None
    publication_year: int | None = None
    doi_or_identifier: str | None = None
    url: str | None = None
    access_date: date
    country: str = "Nigeria"
    basin_or_area: str
    geological_subject: str
    licence_code: str = "OPEN_PEER_REVIEWED_METADATA"
    source_quality_tier: SourceQualityTier
    peer_review_status: str = "PEER_REVIEWED"
    notes: str | None = None


class KnowledgeClaimCreate(BaseModel):
    claim_text: str = Field(min_length=10)
    subject: str
    geological_discipline: str
    country: str = "Nigeria"
    basin: str
    sub_basin_or_province: str | None = None
    formation: str | None = None
    age_interval: str | None = None
    claim_classification: ClaimClassification
    source_quality_tier: SourceQualityTier
    limitations: str = Field(min_length=5)
    applicability_scope: str = Field(min_length=5)
    source_ids: list[UUID] = Field(min_length=1)


class KnowledgeReviewDecision(BaseModel):
    decision: ReviewStatus
    review_rationale: str = Field(min_length=5)
