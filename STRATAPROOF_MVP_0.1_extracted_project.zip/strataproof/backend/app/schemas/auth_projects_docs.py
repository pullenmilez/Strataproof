from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, EmailStr, Field
from app.core.enums import ProcessingStatus, UserRole


class RegisterRequest(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=2, max_length=255)
    password: str = Field(min_length=10, max_length=128)
    organisation_name: str = Field(min_length=2, max_length=255)
    country: str = Field(default="Nigeria", max_length=120)
    professional_credentials: str | None = Field(default=None, max_length=255)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: UUID
    organisation_id: UUID
    role: UserRole


class UserProfileOut(BaseModel):
    user_id: UUID
    email: str
    full_name: str
    professional_credentials: str | None
    organisation_id: UUID
    organisation_name: str
    role: UserRole


class ProjectCreate(BaseModel):
    name: str = Field(min_length=2, max_length=255)
    code: str = Field(min_length=2, max_length=80)
    country: str = Field(default="Nigeria", max_length=120)
    description: str | None = None


class ProjectOut(BaseModel):
    id: UUID
    organisation_id: UUID
    name: str
    code: str
    country: str
    description: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class ProspectCreate(BaseModel):
    project_id: UUID
    name: str = Field(min_length=2, max_length=255)
    block_or_licence: str | None = None
    country: str = Field(default="Nigeria", max_length=120)
    basin_name: str = Field(min_length=2, max_length=150)
    sub_basin_or_province: str | None = None
    target_formations: list[str] = Field(default_factory=list)
    description: str | None = None


class ProspectOut(BaseModel):
    id: UUID
    organisation_id: UUID
    project_id: UUID
    name: str
    block_or_licence: str | None
    country: str
    basin_name: str
    sub_basin_or_province: str | None
    target_formations: list[str]
    description: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class DocumentVersionOut(BaseModel):
    id: UUID
    version_number: int
    original_filename: str
    mime_type: str
    file_size_bytes: int
    sha256_checksum: str
    created_at: datetime
    download_url: str | None = None

    model_config = {"from_attributes": True}


class DocumentOut(BaseModel):
    id: UUID
    organisation_id: UUID
    project_id: UUID
    prospect_id: UUID
    title: str
    document_type: str
    current_version: int
    versions: list[DocumentVersionOut] = []

    model_config = {"from_attributes": True}


class IngestionStatusOut(BaseModel):
    job_id: UUID
    document_version_id: UUID
    status: ProcessingStatus
    extraction_warnings: list[str]
    error_message: str | None
    completed_at: datetime | None
