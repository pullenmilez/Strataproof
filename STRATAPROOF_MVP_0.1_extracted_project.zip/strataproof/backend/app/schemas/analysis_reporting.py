from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, Field
from app.core.enums import (
    ContradictionOutcome,
    PetroleumSystemElementType,
    ProcessingStatus,
    QualitativeStatus,
    ReviewStatus,
    SeverityLevel,
)


class AnalysisRunOut(BaseModel):
    id: UUID
    prospect_id: UUID
    run_type: str
    status: ProcessingStatus
    executed_rule_versions: list[dict]
    ai_model_used: str | None
    started_at: datetime
    completed_at: datetime | None

    model_config = {"from_attributes": True}


class ContradictionOut(BaseModel):
    id: UUID
    category: str
    outcome_classification: ContradictionOutcome
    severity: SeverityLevel
    well_or_interval: str | None
    first_value_raw: str
    second_value_raw: str
    units: str | None
    explanation: str
    possible_geological_causes: list[str]
    review_status: ReviewStatus

    model_config = {"from_attributes": True}


class ContradictionResolveRequest(BaseModel):
    outcome_classification: ContradictionOutcome
    resolution_notes: str = Field(min_length=5)


class PetroleumSystemElementOut(BaseModel):
    id: UUID
    element_type: PetroleumSystemElementType
    qualitative_status: QualitativeStatus
    status_rationale: str
    missing_evidence_summary: list[str]
    review_status: ReviewStatus

    model_config = {"from_attributes": True}


class FalsificationHypothesisOut(BaseModel):
    id: UUID
    element_id: UUID
    proposed_failure_mechanism: str
    geological_applicability: str
    relevance_conditions: str
    missing_evidence: list[str]
    knowledge_source_ids: list[str]
    confidence_rationale: str
    is_ai_suggested: bool
    review_status: ReviewStatus
    reviewer_notes: str | None

    model_config = {"from_attributes": True}


class HypothesisReviewRequest(BaseModel):
    decision: ReviewStatus
    reviewer_notes: str = Field(min_length=5)


class AssessmentCreateRequest(BaseModel):
    title: str = Field(default="Prospect Geological Assurance & Falsification Assessment", min_length=5, max_length=300)
    scope_and_limitations: str = Field(
        default=(
            "This assessment evaluates documentary consistency, evidence support, and petroleum-system failure modes "
            "using verified prospect records and approved geological knowledge sources. It does not compute discovery "
            "probabilities, reserve volumes, or commercial economic valuations."
        ),
        min_length=10,
    )


class AssessmentVersionOut(BaseModel):
    id: UUID
    assessment_id: UUID
    version_number: int
    pdf_sha256: str
    generated_at: datetime
    download_url: str | None = None

    model_config = {"from_attributes": True}
