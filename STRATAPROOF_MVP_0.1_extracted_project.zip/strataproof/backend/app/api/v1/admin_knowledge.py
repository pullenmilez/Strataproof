from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.enums import ReviewStatus, SourceQualityTier, UserRole
from app.core.security import TenantContext, get_tenant_context, require_roles
from app.models.knowledge import (
    BasinProfile,
    FormationRecord,
    GeologicalKnowledgeClaim,
    KnowledgeClaimSource,
    KnowledgeReview,
    KnowledgeSource,
    SourceLicence,
)
from app.schemas.evidence_knowledge import (
    KnowledgeClaimCreate,
    KnowledgeReviewDecision,
    KnowledgeSourceCreate,
)

router = APIRouter(tags=["Curated Geological Knowledge Library (Environment B)"])


@router.get("/knowledge/basins")
def list_basin_profiles(
    country: str = Query(default="Nigeria"),
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    basins = (
        db.query(BasinProfile)
        .filter(
            BasinProfile.country.ilike(country.strip()),
            BasinProfile.review_status.in_([ReviewStatus.APPROVED, ReviewStatus.CONDITIONALLY_APPROVED]),
            BasinProfile.deleted_at.is_(None),
        )
        .order_by(BasinProfile.basin_name.asc())
        .all()
    )
    return [
        {
            "id": str(b.id),
            "country": b.country,
            "basin_name": b.basin_name,
            "basin_category": b.basin_category,
            "sub_basins_or_provinces": b.sub_basins_or_provinces,
            "tectonic_summary": b.tectonic_summary,
            "stratigraphic_overview": b.stratigraphic_overview,
            "known_uncertainties_and_gaps": b.known_uncertainties_and_gaps,
            "review_status": b.review_status.value,
        }
        for b in basins
    ]


@router.get("/knowledge/basins/{basin_id}/formations")
def list_basin_formations(
    basin_id: UUID,
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    formations = (
        db.query(FormationRecord)
        .filter(
            FormationRecord.basin_profile_id == basin_id,
            FormationRecord.review_status.in_([ReviewStatus.APPROVED, ReviewStatus.CONDITIONALLY_APPROVED]),
            FormationRecord.deleted_at.is_(None),
        )
        .order_by(FormationRecord.stratigraphic_rank_order.asc())
        .all()
    )
    return [
        {
            "id": str(f.id),
            "formation_name": f.formation_name,
            "recognized_aliases": f.recognized_aliases,
            "stratigraphic_rank_order": f.stratigraphic_rank_order,
            "age_range": f.age_range,
            "dominant_lithology": f.dominant_lithology,
            "petroleum_system_role": f.petroleum_system_role,
        }
        for f in formations
    ]


@router.post("/admin/knowledge/sources", status_code=status.HTTP_201_CREATED)
def register_knowledge_source(
    payload: KnowledgeSourceCreate,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.KNOWLEDGE_CURATOR, UserRole.LEAD_GEOLOGIST)),
    db: Session = Depends(get_db),
):
    licence = db.query(SourceLicence).filter(SourceLicence.licence_code == payload.licence_code).first()
    if not licence:
        licence = SourceLicence(
            licence_code=payload.licence_code,
            name="Standard Geological Bibliographic & Snippet Licence",
            permits_full_text_storage=False,
            permits_snippet_retrieval=True,
            attribution_requirements="Full bibliographic citation required.",
        )
        db.add(licence)
        db.flush()

    src = KnowledgeSource(
        title=payload.title.strip(),
        authors_or_institution=payload.authors_or_institution.strip(),
        publication_type=payload.publication_type,
        publisher_or_journal=payload.publisher_or_journal,
        publication_year=payload.publication_year,
        doi_or_identifier=payload.doi_or_identifier,
        url=payload.url,
        access_date=payload.access_date,
        country=payload.country.strip(),
        basin_or_area=payload.basin_or_area.strip(),
        geological_subject=payload.geological_subject.strip(),
        licence_id=licence.id,
        source_quality_tier=payload.source_quality_tier,
        peer_review_status=payload.peer_review_status,
        verification_status=ReviewStatus.UNREVIEWED,
        notes=payload.notes,
    )
    db.add(src)
    db.commit()
    db.refresh(src)
    return {"id": str(src.id), "verification_status": src.verification_status.value}


@router.post("/admin/knowledge/claims", status_code=status.HTTP_201_CREATED)
def submit_knowledge_claim(
    payload: KnowledgeClaimCreate,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.KNOWLEDGE_CURATOR, UserRole.LEAD_GEOLOGIST)),
    db: Session = Depends(get_db),
):
    kclaim = GeologicalKnowledgeClaim(
        claim_text=payload.claim_text.strip(),
        subject=payload.subject.strip(),
        geological_discipline=payload.geological_discipline.strip(),
        country=payload.country.strip(),
        basin=payload.basin.strip(),
        sub_basin_or_province=payload.sub_basin_or_province,
        formation=payload.formation,
        age_interval=payload.age_interval,
        claim_classification=payload.claim_classification,
        source_quality_tier=payload.source_quality_tier,
        review_status=ReviewStatus.UNREVIEWED,
        limitations=payload.limitations.strip(),
        applicability_scope=payload.applicability_scope.strip(),
    )
    db.add(kclaim)
    db.flush()

    for sid in payload.source_ids:
        src = db.query(KnowledgeSource).filter(KnowledgeSource.id == sid).first()
        if not src:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"KnowledgeSource {sid} not found.")
        db.add(KnowledgeClaimSource(knowledge_claim_id=kclaim.id, knowledge_source_id=src.id))

    db.commit()
    db.refresh(kclaim)
    return {"id": str(kclaim.id), "review_status": kclaim.review_status.value}


@router.post("/admin/knowledge/claims/{knowledge_claim_id}/review")
def review_knowledge_claim(
    knowledge_claim_id: UUID,
    payload: KnowledgeReviewDecision,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.KNOWLEDGE_CURATOR, UserRole.LEAD_GEOLOGIST)),
    db: Session = Depends(get_db),
):
    kclaim = db.query(GeologicalKnowledgeClaim).filter(GeologicalKnowledgeClaim.id == knowledge_claim_id).first()
    if not kclaim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Knowledge claim not found.")

    if kclaim.source_quality_tier == SourceQualityTier.QUARANTINED_UNVERIFIED and payload.decision == ReviewStatus.APPROVED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="QUARANTINED_UNVERIFIED items cannot be approved directly without upgrading source quality tier.",
        )

    kclaim.review_status = payload.decision
    if payload.decision == ReviewStatus.DISPUTED:
        kclaim.is_disputed = True

    if payload.decision in {ReviewStatus.APPROVED, ReviewStatus.CONDITIONALLY_APPROVED, ReviewStatus.DISPUTED}:
        links = db.query(KnowledgeClaimSource).filter(KnowledgeClaimSource.knowledge_claim_id == kclaim.id).all()
        for lk in links:
            src = db.query(KnowledgeSource).filter(KnowledgeSource.id == lk.knowledge_source_id).first()
            if src and src.verification_status == ReviewStatus.UNREVIEWED:
                src.verification_status = payload.decision

    db.add(
        KnowledgeReview(
            knowledge_claim_id=kclaim.id,
            reviewer_user_id=ctx.user.id,
            decision=payload.decision,
            review_rationale=payload.review_rationale.strip(),
        )
    )
    db.commit()
    return {"id": str(kclaim.id), "review_status": kclaim.review_status.value}
