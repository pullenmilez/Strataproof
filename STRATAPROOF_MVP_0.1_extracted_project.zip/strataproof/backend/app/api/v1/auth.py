import re
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.enums import UserRole
from app.core.security import (
    TenantContext,
    create_access_token,
    get_tenant_context,
    hash_password,
    verify_password,
)
from app.models.operational import Organisation, OrganisationMembership, User
from app.schemas.auth_projects_docs import LoginRequest, RegisterRequest, TokenResponse, UserProfileOut
from app.services.audit import record_audit_event

router = APIRouter(prefix="/auth", tags=["Authentication & Tenancy"])


def _slugify(name: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "org"
    return base[:90]


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
def register_user_and_organisation(payload: RegisterRequest, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == payload.email.lower()).first()
    if existing:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email is already registered.")

    slug_base = _slugify(payload.organisation_name)
    slug = slug_base
    suffix = 1
    while db.query(Organisation).filter(Organisation.slug == slug).first():
        suffix += 1
        slug = f"{slug_base}-{suffix}"

    org = Organisation(
        name=payload.organisation_name.strip(),
        slug=slug,
        country=payload.country.strip(),
        ai_processing_authorized=False,
    )
    user = User(
        email=payload.email.lower().strip(),
        full_name=payload.full_name.strip(),
        password_hash=hash_password(payload.password),
        professional_credentials=payload.professional_credentials,
    )
    db.add_all([org, user])
    db.flush()

    membership = OrganisationMembership(
        organisation_id=org.id,
        user_id=user.id,
        role=UserRole.ORG_ADMIN,
        is_default=True,
    )
    db.add(membership)
    record_audit_event(
        db,
        organisation_id=org.id,
        actor_user_id=user.id,
        event_type="ORGANISATION_AND_ADMIN_REGISTERED",
        entity_type="organisation",
        entity_id=org.id,
        event_metadata={"email": user.email},
    )
    db.commit()

    token = create_access_token(user.id, org.id, membership.role)
    return TokenResponse(
        access_token=token,
        user_id=user.id,
        organisation_id=org.id,
        role=membership.role,
    )


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email.lower().strip(), User.is_active.is_(True)).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid email or password.")

    membership = (
        db.query(OrganisationMembership)
        .filter(OrganisationMembership.user_id == user.id, OrganisationMembership.deleted_at.is_(None))
        .order_by(OrganisationMembership.is_default.desc())
        .first()
    )
    if not membership:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No active organisation membership found.")

    token = create_access_token(user.id, membership.organisation_id, membership.role)
    return TokenResponse(
        access_token=token,
        user_id=user.id,
        organisation_id=membership.organisation_id,
        role=membership.role,
    )


@router.get("/me", response_model=UserProfileOut)
def get_current_profile(ctx: TenantContext = Depends(get_tenant_context)):
    return UserProfileOut(
        user_id=ctx.user.id,
        email=ctx.user.email,
        full_name=ctx.user.full_name,
        professional_credentials=ctx.user.professional_credentials,
        organisation_id=ctx.organisation.id,
        organisation_name=ctx.organisation.name,
        role=ctx.role,
    )
