from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.enums import UserRole
from app.core.security import TenantContext, get_tenant_context, require_roles
from app.models.operational import (
    Contradiction,
    ContradictionResolution,
    FalsificationHypothesis,
    Investigation,
    InvestigationRanking,
    PetroleumSystemElement,
    Prospect,
)
from app.schemas.analysis_reporting import (
    AnalysisRunOut,
    ContradictionOut,
    ContradictionResolveRequest,
    FalsificationHypothesisOut,
    HypothesisReviewRequest,
    PetroleumSystemElementOut,
)
from app.services.audit import record_audit_event
from app.services.falsification.engine import run_petroleum_system_falsification
from app.services.validation.rule_engine import run_deterministic_validation

router = APIRouter(tags=["Validation & Petroleum System Falsification"])


def _get_tenant_prospect(db: Session, prospect_id: UUID, org_id: UUID) -> Prospect:
    prospect = (
        db.query(Prospect)
        .filter(Prospect.id == prospect_id, Prospect.organisation_id == org_id, Prospect.deleted_at.is_(None))
        .first()
    )
    if not prospect:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prospect not found in your organisation.")
    return prospect


@router.post("/prospects/{prospect_id}/validate", response_model=AnalysisRunOut)
def trigger_deterministic_validation(
    prospect_id: UUID,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.GEOSCIENTIST)),
    db: Session = Depends(get_db),
):
    prospect = _get_tenant_prospect(db, prospect_id, ctx.organisation.id)
    run = run_deterministic_validation(db, prospect=prospect, triggered_by_user_id=ctx.user.id)
    record_audit_event(
        db,
        organisation_id=ctx.organisation.id,
        project_id=prospect.project_id,
        actor_user_id=ctx.user.id,
        event_type="DETERMINISTIC_VALIDATION_EXECUTED",
        entity_type="analysis_run",
        entity_id=run.id,
    )
    db.commit()
    return run


@router.get("/prospects/{prospect_id}/contradictions", response_model=list[ContradictionOut])
def list_prospect_contradictions(
    prospect_id: UUID,
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    _get_tenant_prospect(db, prospect_id, ctx.organisation.id)
    return (
        db.query(Contradiction)
        .filter(
            Contradiction.prospect_id == prospect_id,
            Contradiction.organisation_id == ctx.organisation.id,
            Contradiction.deleted_at.is_(None),
        )
        .order_by(Contradiction.created_at.desc())
        .all()
    )


@router.post("/contradictions/{contradiction_id}/resolve", response_model=ContradictionOut)
def resolve_contradiction(
    contradiction_id: UUID,
    payload: ContradictionResolveRequest,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.REVIEWER)),
    db: Session = Depends(get_db),
):
    ct = (
        db.query(Contradiction)
        .filter(
            Contradiction.id == contradiction_id,
            Contradiction.organisation_id == ctx.organisation.id,
            Contradiction.deleted_at.is_(None),
        )
        .first()
    )
    if not ct:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Contradiction not found.")

    from app.core.enums import ReviewStatus

    ct.outcome_classification = payload.outcome_classification
    ct.review_status = ReviewStatus.APPROVED
    db.add(
        ContradictionResolution(
            organisation_id=ctx.organisation.id,
            contradiction_id=ct.id,
            reviewer_id=ctx.user.id,
            outcome_classification=payload.outcome_classification,
            resolution_notes=payload.resolution_notes.strip(),
        )
    )
    db.commit()
    db.refresh(ct)
    return ct


@router.post("/prospects/{prospect_id}/falsify", response_model=AnalysisRunOut)
def trigger_falsification_analysis(
    prospect_id: UUID,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.GEOSCIENTIST)),
    db: Session = Depends(get_db),
):
    prospect = _get_tenant_prospect(db, prospect_id, ctx.organisation.id)
    run = run_petroleum_system_falsification(db, prospect=prospect, triggered_by_user_id=ctx.user.id)
    record_audit_event(
        db,
        organisation_id=ctx.organisation.id,
        project_id=prospect.project_id,
        actor_user_id=ctx.user.id,
        event_type="FALSIFICATION_ANALYSIS_EXECUTED",
        entity_type="analysis_run",
        entity_id=run.id,
    )
    db.commit()
    return run


@router.get("/prospects/{prospect_id}/petroleum-system", response_model=list[PetroleumSystemElementOut])
def get_petroleum_system_elements(
    prospect_id: UUID,
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    _get_tenant_prospect(db, prospect_id, ctx.organisation.id)
    return (
        db.query(PetroleumSystemElement)
        .filter(
            PetroleumSystemElement.prospect_id == prospect_id,
            PetroleumSystemElement.organisation_id == ctx.organisation.id,
        )
        .all()
    )


@router.get("/prospects/{prospect_id}/hypotheses", response_model=list[FalsificationHypothesisOut])
def get_falsification_hypotheses(
    prospect_id: UUID,
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    _get_tenant_prospect(db, prospect_id, ctx.organisation.id)
    return (
        db.query(FalsificationHypothesis)
        .filter(
            FalsificationHypothesis.prospect_id == prospect_id,
            FalsificationHypothesis.organisation_id == ctx.organisation.id,
            FalsificationHypothesis.deleted_at.is_(None),
        )
        .all()
    )


@router.post("/hypotheses/{hypothesis_id}/review", response_model=FalsificationHypothesisOut)
def review_falsification_hypothesis(
    hypothesis_id: UUID,
    payload: HypothesisReviewRequest,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.REVIEWER)),
    db: Session = Depends(get_db),
):
    hyp = (
        db.query(FalsificationHypothesis)
        .filter(
            FalsificationHypothesis.id == hypothesis_id,
            FalsificationHypothesis.organisation_id == ctx.organisation.id,
        )
        .first()
    )
    if not hyp:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Hypothesis not found.")

    hyp.review_status = payload.decision
    hyp.reviewed_by = ctx.user.id
    hyp.reviewer_notes = payload.reviewer_notes.strip()
    db.commit()
    db.refresh(hyp)
    return hyp


@router.get("/prospects/{prospect_id}/investigations")
def list_prioritized_investigations(
    prospect_id: UUID,
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    _get_tenant_prospect(db, prospect_id, ctx.organisation.id)
    rows = (
        db.query(Investigation, InvestigationRanking)
        .join(InvestigationRanking, InvestigationRanking.investigation_id == Investigation.id)
        .filter(
            Investigation.prospect_id == prospect_id,
            Investigation.organisation_id == ctx.organisation.id,
        )
        .order_by(InvestigationRanking.priority_rank.asc())
        .all()
    )
    return [
        {
            "id": str(inv.id),
            "priority_rank": rk.priority_rank,
            "decision_relevance": rk.decision_relevance,
            "title": inv.title,
            "discriminating_objective": inv.discriminating_objective,
            "required_data_or_test": inv.required_data_or_test,
            "technical_feasibility_note": inv.technical_feasibility_note,
            "user_supplied_cost_estimate": inv.user_supplied_cost_estimate,
            "user_supplied_time_estimate": inv.user_supplied_time_estimate,
            "prioritisation_rationale": rk.prioritisation_rationale,
        }
        for inv, rk in rows
    ]
