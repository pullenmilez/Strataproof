from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.enums import UserRole
from app.core.security import TenantContext, get_tenant_context, require_roles
from app.models.knowledge import BasinProfile
from app.models.operational import Project, Prospect
from app.schemas.auth_projects_docs import ProjectCreate, ProjectOut, ProspectCreate, ProspectOut
from app.services.audit import record_audit_event

router = APIRouter(tags=["Projects & Prospects"])


@router.post("/projects", response_model=ProjectOut, status_code=status.HTTP_201_CREATED)
def create_project(
    payload: ProjectCreate,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.GEOSCIENTIST)),
    db: Session = Depends(get_db),
):
    project = Project(
        organisation_id=ctx.organisation.id,
        name=payload.name.strip(),
        code=payload.code.strip().upper(),
        country=payload.country.strip(),
        description=payload.description,
        created_by=ctx.user.id,
    )
    db.add(project)
    db.flush()
    record_audit_event(
        db,
        organisation_id=ctx.organisation.id,
        project_id=project.id,
        actor_user_id=ctx.user.id,
        event_type="PROJECT_CREATED",
        entity_type="project",
        entity_id=project.id,
        event_metadata={"code": project.code},
    )
    db.commit()
    db.refresh(project)
    return project


@router.get("/projects", response_model=list[ProjectOut])
def list_projects(ctx: TenantContext = Depends(get_tenant_context), db: Session = Depends(get_db)):
    return (
        db.query(Project)
        .filter(Project.organisation_id == ctx.organisation.id, Project.deleted_at.is_(None))
        .order_by(Project.created_at.desc())
        .all()
    )


@router.post("/prospects", response_model=ProspectOut, status_code=status.HTTP_201_CREATED)
def create_prospect(
    payload: ProspectCreate,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.GEOSCIENTIST)),
    db: Session = Depends(get_db),
):
    project = (
        db.query(Project)
        .filter(
            Project.id == payload.project_id,
            Project.organisation_id == ctx.organisation.id,
            Project.deleted_at.is_(None),
        )
        .first()
    )
    if not project:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Project not found in your organisation.")

    basin_profile = (
        db.query(BasinProfile)
        .filter(
            BasinProfile.country.ilike(payload.country.strip()),
            BasinProfile.basin_name.ilike(payload.basin_name.strip()),
            BasinProfile.deleted_at.is_(None),
        )
        .first()
    )

    prospect = Prospect(
        organisation_id=ctx.organisation.id,
        project_id=project.id,
        name=payload.name.strip(),
        block_or_licence=payload.block_or_licence,
        country=payload.country.strip(),
        basin_name=payload.basin_name.strip(),
        sub_basin_or_province=payload.sub_basin_or_province,
        basin_profile_id=basin_profile.id if basin_profile else None,
        target_formations=payload.target_formations,
        description=payload.description,
        created_by=ctx.user.id,
    )
    db.add(prospect)
    db.flush()
    record_audit_event(
        db,
        organisation_id=ctx.organisation.id,
        project_id=project.id,
        actor_user_id=ctx.user.id,
        event_type="PROSPECT_CREATED",
        entity_type="prospect",
        entity_id=prospect.id,
        event_metadata={"basin_name": prospect.basin_name},
    )
    db.commit()
    db.refresh(prospect)
    return prospect


@router.get("/prospects/{prospect_id}", response_model=ProspectOut)
def get_prospect(
    prospect_id: UUID,
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    prospect = (
        db.query(Prospect)
        .filter(
            Prospect.id == prospect_id,
            Prospect.organisation_id == ctx.organisation.id,
            Prospect.deleted_at.is_(None),
        )
        .first()
    )
    if not prospect:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prospect not found.")
    return prospect
