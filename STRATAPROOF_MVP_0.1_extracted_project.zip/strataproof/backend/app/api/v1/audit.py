from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import TenantContext, get_tenant_context
from app.models.operational import AuditEvent

router = APIRouter(prefix="/audit", tags=["Audit Trail & Lineage"])


@router.get("/events")
def list_organisation_audit_events(
    limit: int = Query(default=100, ge=1, le=500),
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    events = (
        db.query(AuditEvent)
        .filter(AuditEvent.organisation_id == ctx.organisation.id)
        .order_by(AuditEvent.occurred_at.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "id": str(ev.id),
            "event_type": ev.event_type,
            "entity_type": ev.entity_type,
            "entity_id": ev.entity_id,
            "actor_user_id": str(ev.actor_user_id) if ev.actor_user_id else None,
            "project_id": str(ev.project_id) if ev.project_id else None,
            "event_metadata": ev.event_metadata,
            "occurred_at": ev.occurred_at.isoformat(),
        }
        for ev in events
    ]
