from uuid import UUID
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.enums import ProcessingStatus, UserRole
from app.core.security import TenantContext, get_tenant_context, require_roles
from app.models.operational import Document, DocumentVersion, IngestionJob, Prospect
from app.schemas.auth_projects_docs import DocumentOut, DocumentVersionOut, IngestionStatusOut
from app.services.audit import record_audit_event
from app.services.storage import PrivateObjectStorageService
from app.worker.celery_app import process_document_version_task

router = APIRouter(prefix="/documents", tags=["Geological Documents & Ingestion"])


@router.post("/upload", response_model=DocumentOut, status_code=status.HTTP_201_CREATED)
async def upload_geological_document(
    prospect_id: UUID = Form(...),
    title: str = Form(...),
    document_type: str = Form(...),
    existing_document_id: UUID | None = Form(default=None),
    file: UploadFile = File(...),
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.GEOSCIENTIST)),
    db: Session = Depends(get_db),
):
    prospect = (
        db.query(Prospect)
        .filter(
            Prospect.id == prospect_id,
            Prospect.organisation_id == ctx.organisation.id,
            Prospect.deleted_at.is_(None),
        )
        .first()
    )
    if not prospect:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prospect not found in your organisation.")

    raw_bytes = await file.read()
    storage = PrivateObjectStorageService()

    if existing_document_id:
        doc = (
            db.query(Document)
            .filter(
                Document.id == existing_document_id,
                Document.prospect_id == prospect.id,
                Document.organisation_id == ctx.organisation.id,
                Document.deleted_at.is_(None),
            )
            .first()
        )
        if not doc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Target document for new version not found.")
        doc.current_version += 1
        version_num = doc.current_version
    else:
        doc = Document(
            organisation_id=ctx.organisation.id,
            project_id=prospect.project_id,
            prospect_id=prospect.id,
            title=title.strip(),
            document_type=document_type.strip(),
            current_version=1,
            created_by=ctx.user.id,
        )
        db.add(doc)
        db.flush()
        version_num = 1

    stored = storage.upload_customer_document(
        organisation_id=ctx.organisation.id,
        project_id=prospect.project_id,
        document_id=doc.id,
        version_number=version_num,
        original_filename=file.filename or "document.bin",
        content=raw_bytes,
        mime_type=file.content_type or "application/octet-stream",
    )

    doc_ver = DocumentVersion(
        organisation_id=ctx.organisation.id,
        document_id=doc.id,
        version_number=version_num,
        original_filename=stored.sanitized_filename,
        mime_type=file.content_type or "application/octet-stream",
        file_size_bytes=stored.file_size_bytes,
        sha256_checksum=stored.sha256_checksum,
        s3_bucket=stored.bucket,
        s3_object_key=stored.object_key,
        uploaded_by=ctx.user.id,
    )
    db.add(doc_ver)
    db.flush()

    job = IngestionJob(
        organisation_id=ctx.organisation.id,
        document_version_id=doc_ver.id,
        status=ProcessingStatus.PENDING,
    )
    db.add(job)
    db.flush()

    record_audit_event(
        db,
        organisation_id=ctx.organisation.id,
        project_id=prospect.project_id,
        actor_user_id=ctx.user.id,
        event_type="DOCUMENT_VERSION_UPLOADED",
        entity_type="document_version",
        entity_id=doc_ver.id,
        event_metadata={
            "filename": stored.sanitized_filename,
            "sha256": stored.sha256_checksum,
            "version": version_num,
        },
    )
    db.commit()

    task = process_document_version_task.delay(str(job.id))
    job.celery_task_id = task.id
    db.commit()
    db.refresh(doc)
    return doc


@router.get("/{document_id}", response_model=DocumentOut)
def get_document_with_presigned_urls(
    document_id: UUID,
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    doc = (
        db.query(Document)
        .filter(
            Document.id == document_id,
            Document.organisation_id == ctx.organisation.id,
            Document.deleted_at.is_(None),
        )
        .first()
    )
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found.")

    storage = PrivateObjectStorageService()
    versions_out: list[DocumentVersionOut] = []
    for v in doc.versions:
        vo = DocumentVersionOut.model_validate(v)
        vo.download_url = storage.generate_presigned_download_url(
            bucket=v.s3_bucket,
            object_key=v.s3_object_key,
            filename=v.original_filename,
        )
        versions_out.append(vo)

    out = DocumentOut.model_validate(doc)
    out.versions = versions_out
    return out


@router.get("/versions/{document_version_id}/ingestion", response_model=IngestionStatusOut)
def get_ingestion_status(
    document_version_id: UUID,
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    job = (
        db.query(IngestionJob)
        .filter(
            IngestionJob.document_version_id == document_version_id,
            IngestionJob.organisation_id == ctx.organisation.id,
        )
        .order_by(IngestionJob.created_at.desc())
        .first()
    )
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ingestion job not found.")
    return IngestionStatusOut(
        job_id=job.id,
        document_version_id=job.document_version_id,
        status=job.status,
        extraction_warnings=job.extraction_warnings,
        error_message=job.error_message,
        completed_at=job.completed_at,
    )
