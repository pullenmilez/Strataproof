from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.enums import ReviewStatus, UserRole
from app.core.security import TenantContext, get_tenant_context, require_roles
from app.models.operational import (
    ClaimEvidence,
    ClaimReview,
    ClaimRevision,
    EvidenceItem,
    GeologicalClaim,
    Prospect,
)
from app.schemas.evidence_knowledge import (
    ClaimCreate,
    ClaimOut,
    ClaimReviewRequest,
    ClaimReviseRequest,
    EvidenceCreate,
    EvidenceOut,
    LinkClaimEvidenceRequest,
)
from app.services.audit import record_audit_event

router = APIRouter(tags=["Geological Evidence Ledger"])


@router.post("/claims", response_model=ClaimOut, status_code=status.HTTP_201_CREATED)
def create_geological_claim(
    payload: ClaimCreate,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.GEOSCIENTIST)),
    db: Session = Depends(get_db),
):
    prospect = (
        db.query(Prospect)
        .filter(
            Prospect.id == payload.prospect_id,
            Prospect.organisation_id == ctx.organisation.id,
            Prospect.deleted_at.is_(None),
        )
        .first()
    )
    if not prospect:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prospect not found.")

    initial_review = (
        ReviewStatus.AI_SUGGESTED_PENDING_REVIEW
        if payload.is_ai_suggested
        else ReviewStatus.UNREVIEWED
    )
    claim = GeologicalClaim(
        organisation_id=ctx.organisation.id,
        prospect_id=prospect.id,
        geological_element=payload.geological_element.strip(),
        petroleum_system_element=payload.petroleum_system_element,
        claim_text=payload.claim_text.strip(),
        claim_classification=payload.claim_classification,
        stratigraphic_applicability=payload.stratigraphic_applicability,
        spatial_applicability=payload.spatial_applicability,
        conditions_and_limitations=payload.conditions_and_limitations,
        review_status=initial_review,
        is_ai_suggested=payload.is_ai_suggested,
        current_revision=1,
        created_by=ctx.user.id,
    )
    db.add(claim)
    db.flush()

    db.add(
        ClaimRevision(
            organisation_id=ctx.organisation.id,
            claim_id=claim.id,
            revision_number=1,
            claim_text=claim.claim_text,
            claim_classification=claim.claim_classification,
            conditions_and_limitations=claim.conditions_and_limitations,
            change_reason="Initial claim creation in Evidence Ledger",
            revised_by=ctx.user.id,
        )
    )
    record_audit_event(
        db,
        organisation_id=ctx.organisation.id,
        project_id=prospect.project_id,
        actor_user_id=ctx.user.id,
        event_type="GEOLOGICAL_CLAIM_CREATED",
        entity_type="geological_claim",
        entity_id=claim.id,
        event_metadata={"classification": claim.claim_classification.value},
    )
    db.commit()
    db.refresh(claim)
    return claim


@router.get("/prospects/{prospect_id}/claims", response_model=list[ClaimOut])
def list_prospect_claims(
    prospect_id: UUID,
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    return (
        db.query(GeologicalClaim)
        .filter(
            GeologicalClaim.prospect_id == prospect_id,
            GeologicalClaim.organisation_id == ctx.organisation.id,
            GeologicalClaim.deleted_at.is_(None),
        )
        .order_by(GeologicalClaim.created_at.desc())
        .all()
    )


@router.patch("/claims/{claim_id}/revise", response_model=ClaimOut)
def revise_geological_claim(
    claim_id: UUID,
    payload: ClaimReviseRequest,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.GEOSCIENTIST)),
    db: Session = Depends(get_db),
):
    claim = (
        db.query(GeologicalClaim)
        .filter(
            GeologicalClaim.id == claim_id,
            GeologicalClaim.organisation_id == ctx.organisation.id,
            GeologicalClaim.deleted_at.is_(None),
        )
        .first()
    )
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Geological claim not found.")

    claim.current_revision += 1
    claim.claim_text = payload.claim_text.strip()
    claim.claim_classification = payload.claim_classification
    claim.conditions_and_limitations = payload.conditions_and_limitations
    claim.review_status = ReviewStatus.UNREVIEWED

    db.add(
        ClaimRevision(
            organisation_id=ctx.organisation.id,
            claim_id=claim.id,
            revision_number=claim.current_revision,
            claim_text=claim.claim_text,
            claim_classification=claim.claim_classification,
            conditions_and_limitations=claim.conditions_and_limitations,
            change_reason=payload.change_reason.strip(),
            revised_by=ctx.user.id,
        )
    )
    db.commit()
    db.refresh(claim)
    return claim


@router.post("/evidence", response_model=EvidenceOut, status_code=status.HTTP_201_CREATED)
def create_evidence_item(
    payload: EvidenceCreate,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.GEOSCIENTIST)),
    db: Session = Depends(get_db),
):
    prospect = (
        db.query(Prospect)
        .filter(
            Prospect.id == payload.prospect_id,
            Prospect.organisation_id == ctx.organisation.id,
            Prospect.deleted_at.is_(None),
        )
        .first()
    )
    if not prospect:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prospect not found.")

    ev = EvidenceItem(
        organisation_id=ctx.organisation.id,
        prospect_id=prospect.id,
        document_version_id=payload.document_version_id,
        source_location_id=payload.source_location_id,
        evidence_type=payload.evidence_type.strip(),
        geological_subject=payload.geological_subject.strip(),
        evidence_description=payload.evidence_description.strip(),
        well_identifier=payload.well_identifier,
        formation=payload.formation,
        depth_interval_raw=payload.depth_interval_raw,
        depth_unit=payload.depth_unit,
        evidence_strength_note=payload.evidence_strength_note,
        created_by=ctx.user.id,
    )
    db.add(ev)
    db.commit()
    db.refresh(ev)
    return ev


@router.post("/claims/{claim_id}/evidence", status_code=status.HTTP_201_CREATED)
def link_evidence_to_claim(
    claim_id: UUID,
    payload: LinkClaimEvidenceRequest,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.GEOSCIENTIST)),
    db: Session = Depends(get_db),
):
    claim = (
        db.query(GeologicalClaim)
        .filter(
            GeologicalClaim.id == claim_id,
            GeologicalClaim.organisation_id == ctx.organisation.id,
            GeologicalClaim.deleted_at.is_(None),
        )
        .first()
    )
    evidence = (
        db.query(EvidenceItem)
        .filter(
            EvidenceItem.id == payload.evidence_id,
            EvidenceItem.organisation_id == ctx.organisation.id,
            EvidenceItem.deleted_at.is_(None),
        )
        .first()
    )
    if not claim or not evidence:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim or EvidenceItem not found.")

    link = ClaimEvidence(
        organisation_id=ctx.organisation.id,
        claim_id=claim.id,
        evidence_id=evidence.id,
        relationship_role=payload.relationship_role,
        rationale=payload.rationale,
        linked_by=ctx.user.id,
    )
    db.add(link)
    db.commit()
    return {"status": "linked", "claim_id": str(claim.id), "evidence_id": str(evidence.id)}


@router.post("/claims/{claim_id}/review", response_model=ClaimOut)
def review_geological_claim(
    claim_id: UUID,
    payload: ClaimReviewRequest,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.REVIEWER)),
    db: Session = Depends(get_db),
):
    claim = (
        db.query(GeologicalClaim)
        .filter(
            GeologicalClaim.id == claim_id,
            GeologicalClaim.organisation_id == ctx.organisation.id,
            GeologicalClaim.deleted_at.is_(None),
        )
        .first()
    )
    if not claim:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Claim not found.")

    claim.review_status = payload.decision
    if payload.qualitative_status:
        claim.qualitative_status = payload.qualitative_status

    db.add(
        ClaimReview(
            organisation_id=ctx.organisation.id,
            claim_id=claim.id,
            reviewer_id=ctx.user.id,
            decision=payload.decision,
            reviewer_notes=payload.reviewer_notes.strip(),
        )
    )
    db.commit()
    db.refresh(claim)
    return claim
