from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import get_db
from app.core.enums import UserRole
from app.core.security import TenantContext, get_tenant_context, require_roles
from app.models.operational import Assessment, AssessmentVersion, Prospect
from app.schemas.analysis_reporting import AssessmentCreateRequest, AssessmentVersionOut
from app.services.audit import record_audit_event
from app.services.reporting.pdf_generator import generate_prospect_assessment_pdf
from app.services.storage import PrivateObjectStorageService

router = APIRouter(tags=["Prospect Assessment Reports"])


@router.post("/prospects/{prospect_id}/assessments", response_model=AssessmentVersionOut, status_code=status.HTTP_201_CREATED)
def create_assessment_pdf(
    prospect_id: UUID,
    payload: AssessmentCreateRequest,
    ctx: TenantContext = Depends(require_roles(UserRole.ORG_ADMIN, UserRole.LEAD_GEOLOGIST, UserRole.GEOSCIENTIST)),
    db: Session = Depends(get_db),
):
    prospect = (
        db.query(Prospect)
        .filter(
            Prospect.id == prospect_id,
            Prospect.organisation_id == ctx.organisation.id,
            Prospect.deleted_at.is_(None),
        )
        .first()
    )
    if not prospect:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Prospect not found.")

    av = generate_prospect_assessment_pdf(
        db,
        prospect=prospect,
        generated_by_user=ctx.user,
        title=payload.title,
        scope_and_limitations=payload.scope_and_limitations,
    )
    record_audit_event(
        db,
        organisation_id=ctx.organisation.id,
        project_id=prospect.project_id,
        actor_user_id=ctx.user.id,
        event_type="ASSESSMENT_PDF_GENERATED",
        entity_type="assessment_version",
        entity_id=av.id,
        event_metadata={"version": av.version_number, "pdf_sha256": av.pdf_sha256},
    )
    db.commit()

    storage = PrivateObjectStorageService()
    out = AssessmentVersionOut.model_validate(av)
    out.download_url = storage.generate_presigned_download_url(
        bucket=settings.S3_BUCKET_CUSTOMER_DOCS,
        object_key=av.pdf_s3_key,
        filename=f"{prospect.name}_Assurance_v{av.version_number}.pdf",
    )
    return out


@router.get("/assessment-versions/{version_id}/download")
def download_assessment_pdf_stream(
    version_id: UUID,
    ctx: TenantContext = Depends(get_tenant_context),
    db: Session = Depends(get_db),
):
    av = (
        db.query(AssessmentVersion)
        .filter(
            AssessmentVersion.id == version_id,
            AssessmentVersion.organisation_id == ctx.organisation.id,
        )
        .first()
    )
    if not av:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Assessment version not found.")

    storage = PrivateObjectStorageService()
    pdf_bytes = storage.download_bytes(bucket=settings.S3_BUCKET_CUSTOMER_DOCS, object_key=av.pdf_s3_key)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="strataproof_assessment_v{av.version_number}.pdf"'},
    )
