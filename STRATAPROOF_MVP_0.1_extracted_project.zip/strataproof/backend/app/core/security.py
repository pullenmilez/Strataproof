import hashlib
import hmac
import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from uuid import UUID

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.database import bind_tenant_rls_context, get_db
from app.core.enums import UserRole
from app.models.operational import Organisation, OrganisationMembership, User

ALGORITHM = "HS256"
bearer_scheme = HTTPBearer(auto_error=True)


def hash_password(plain_password: str) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", plain_password.encode("utf-8"), salt.encode("utf-8"), 310_000)
    return f"pbkdf2_sha256$310000${salt}${dk.hex()}"


def verify_password(plain_password: str, stored_hash: str) -> bool:
    try:
        scheme, iter_str, salt, hex_digest = stored_hash.split("$")
        if scheme != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac(
            "sha256",
            plain_password.encode("utf-8"),
            salt.encode("utf-8"),
            int(iter_str),
        )
        return hmac.compare_digest(dk.hex(), hex_digest)
    except Exception:
        return False


def create_access_token(user_id: UUID, organisation_id: UUID, role: UserRole) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {
        "sub": str(user_id),
        "org_id": str(organisation_id),
        "role": role.value,
        "exp": expire,
    }
    return jwt.encode(payload, settings.APP_SECRET_KEY, algorithm=ALGORITHM)


@dataclass(frozen=True)
class TenantContext:
    user: User
    organisation: Organisation
    membership: OrganisationMembership
    role: UserRole


def get_tenant_context(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
    x_organisation_id: str | None = Header(default=None, alias="X-Organisation-ID"),
    db: Session = Depends(get_db),
) -> TenantContext:
    credentials_exc = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired authentication credentials.",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(credentials.credentials, settings.APP_SECRET_KEY, algorithms=[ALGORITHM])
        user_id = UUID(payload["sub"])
        token_org_id = UUID(payload["org_id"])
    except (JWTError, KeyError, ValueError):
        raise credentials_exc

    effective_org_id = token_org_id
    if x_organisation_id:
        try:
            header_org_id = UUID(x_organisation_id)
        except ValueError:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Malformed X-Organisation-ID header.")
        effective_org_id = header_org_id

    user = db.query(User).filter(User.id == user_id, User.is_active.is_(True), User.deleted_at.is_(None)).first()
    if not user:
        raise credentials_exc

    org = (
        db.query(Organisation)
        .filter(Organisation.id == effective_org_id, Organisation.is_active.is_(True), Organisation.deleted_at.is_(None))
        .first()
    )
    if not org:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Organisation access denied.")

    membership = (
        db.query(OrganisationMembership)
        .filter(
            OrganisationMembership.organisation_id == org.id,
            OrganisationMembership.user_id == user.id,
            OrganisationMembership.deleted_at.is_(None),
        )
        .first()
    )
    if not membership:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cross-tenant access denied: user does not belong to the requested organisation.",
        )

    bind_tenant_rls_context(db, str(org.id))
    return TenantContext(user=user, organisation=org, membership=membership, role=membership.role)


def require_roles(*allowed_roles: UserRole):
    def _dependency(ctx: TenantContext = Depends(get_tenant_context)) -> TenantContext:
        if ctx.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role '{ctx.role.value}' is not authorized to perform this action.",
            )
        return ctx

    return _dependency
