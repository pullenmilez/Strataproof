from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from app.core.config import settings

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine, future=True)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def bind_tenant_rls_context(db: Session, organisation_id: str) -> None:
    """Binds the active tenant organisation_id to PostgreSQL session-local RLS variable."""
    if db.bind and db.bind.dialect.name == "postgresql":
        db.execute(
            text("SELECT set_config('app.current_organisation_id', :org_id, true)"),
            {"org_id": str(organisation_id)},
        )
