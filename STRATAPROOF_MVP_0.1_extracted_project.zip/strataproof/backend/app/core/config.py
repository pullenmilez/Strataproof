from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    APP_NAME: str = "STRATAPROOF"
    APP_ENV: str = "development"
    APP_SECRET_KEY: str = "dev-only-override-in-production-env"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480

    DATABASE_URL: str = "postgresql+psycopg://strataproof:strataproof_dev_pass@localhost:5432/strataproof"
    REDIS_URL: str = "redis://localhost:6379/0"

    S3_ENDPOINT_URL: str = "http://localhost:9000"
    S3_ACCESS_KEY: str = "strataproof_minio"
    S3_SECRET_KEY: str = "strataproof_minio_secret_key"
    S3_REGION: str = "us-east-1"
    S3_BUCKET_CUSTOMER_DOCS: str = "strataproof-customer-docs"
    S3_BUCKET_KNOWLEDGE_DOCS: str = "strataproof-knowledge-library"
    S3_USE_SSL: bool = False
    MAX_UPLOAD_SIZE_MB: int = 250

    AI_PROVIDER: str = "disabled"
    AI_API_KEY: str = ""
    AI_MODEL_NAME: str = "gpt-4o-mini"
    AI_REQUEST_TIMEOUT_SECONDS: int = 45
    AI_MAX_TOKENS: int = 1500

    CORS_ORIGINS: list[str] = ["http://localhost:3000"]


settings = Settings()
