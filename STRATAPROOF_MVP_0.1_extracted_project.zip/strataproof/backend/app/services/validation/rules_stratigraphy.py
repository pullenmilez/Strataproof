from dataclasses import dataclass
from uuid import UUID
from app.core.enums import ContradictionOutcome, SeverityLevel


@dataclass
class CandidateContradiction:
    rule_code: str
    category: str
    outcome_classification: ContradictionOutcome
    severity: SeverityLevel
    well_or_interval: str | None
    first_source_location_id: UUID | None
    second_source_location_id: UUID | None
    affected_claim_ids: list[str]
    first_value_raw: str
    second_value_raw: str
    units: str | None
    explanation: str
    possible_geological_causes: list[str]


def check_stratigraphic_order_and_depths(
    *,
    well_identifier: str,
    intervals: list,
    formation_rank_map: dict[str, int],
) -> list[CandidateContradiction]:
    """
    Deterministic Check A & Check B:
    - Verifies top_depth <= bottom_depth within each interval.
    - Detects unit/datum mismatches across intervals in the same well without silent conversion.
    - Checks stratigraphic superposition order against approved FormationRecord rank order
      (where rank 1 = youngest/shallowest, rank N = oldest/deepest) and flags possible
      reverse faulting, thrust repetition, or overturned strata alongside data errors.
    """
    findings: list[CandidateContradiction] = []
    if not intervals:
        return findings

    units_present = {iv.depth_unit.strip().lower() for iv in intervals if iv.depth_unit}
    datums_present = {iv.depth_datum.strip().upper() for iv in intervals if iv.depth_datum}
    types_present = {iv.depth_type.strip().upper() for iv in intervals if iv.depth_type}

    if len(units_present) > 1:
        sorted_u = sorted(units_present)
        findings.append(
            CandidateContradiction(
                rule_code="RULE-DEPTH-UNIT-002",
                category="DEPTH_UNIT_DATUM_INCONSISTENCY",
                outcome_classification=ContradictionOutcome.POTENTIAL_DATA_INCONSISTENCY,
                severity=SeverityLevel.HIGH,
                well_or_interval=well_identifier,
                first_source_location_id=intervals[0].source_location_id,
                second_source_location_id=intervals[-1].source_location_id,
                affected_claim_ids=[],
                first_value_raw=f"units={sorted_u[0]}",
                second_value_raw=f"units={sorted_u[1]}",
                units="mixed",
                explanation=(
                    f"Well '{well_identifier}' mixes incompatible depth units ({', '.join(sorted_u)}) across reported "
                    f"intervals without explicit unit harmonization. Raw values are preserved without silent conversion."
                ),
                possible_geological_causes=[
                    "Composite well-header / mud-log unit transcription mismatch (feet vs metres).",
                ],
            )
        )

    if len(datums_present) > 1 or len(types_present) > 1:
        findings.append(
            CandidateContradiction(
                rule_code="RULE-DEPTH-UNIT-002",
                category="DEPTH_UNIT_DATUM_INCONSISTENCY",
                outcome_classification=ContradictionOutcome.POTENTIAL_DATA_INCONSISTENCY,
                severity=SeverityLevel.MODERATE,
                well_or_interval=well_identifier,
                first_source_location_id=intervals[0].source_location_id,
                second_source_location_id=intervals[-1].source_location_id,
                affected_claim_ids=[],
                first_value_raw=f"datums={sorted(datums_present)}, types={sorted(types_present)}",
                second_value_raw="inconsistent reference datum/type",
                units=next(iter(units_present), None),
                explanation=(
                    f"Well '{well_identifier}' mixes depth reference datums ({sorted(datums_present)}) or depth types "
                    f"({sorted(types_present)}) across stratigraphic picks."
                ),
                possible_geological_causes=[
                    "KB vs MSL datum shift not normalized between legacy and modern well reports.",
                ],
            )
        )

    # Check individual interval geometry
    for iv in intervals:
        if iv.top_depth is not None and iv.bottom_depth is not None and iv.top_depth > iv.bottom_depth:
            findings.append(
                CandidateContradiction(
                    rule_code="RULE-STRAT-ORDER-001",
                    category="STRATIGRAPHIC_ORDER_CONTRADICTION",
                    outcome_classification=ContradictionOutcome.CONFIRMED_DATA_ERROR,
                    severity=SeverityLevel.CRITICAL,
                    well_or_interval=f"{well_identifier} :: {iv.formation_name}",
                    first_source_location_id=iv.source_location_id,
                    second_source_location_id=iv.source_location_id,
                    affected_claim_ids=[],
                    first_value_raw=f"top={iv.top_depth}",
                    second_value_raw=f"bottom={iv.bottom_depth}",
                    units=iv.depth_unit,
                    explanation=(
                        f"Formation '{iv.formation_name}' in well '{well_identifier}' has top depth ({iv.top_depth}) "
                        f"greater than bottom depth ({iv.bottom_depth})."
                    ),
                    possible_geological_causes=["Inverted top/base depth entry in well-top table."],
                )
            )

    # Compare ordered intervals where units match
    comparable = [iv for iv in intervals if iv.top_depth is not None]
    comparable.sort(key=lambda x: x.top_depth)

    for i in range(len(comparable) - 1):
        upper = comparable[i]
        lower = comparable[i + 1]

        if (
            upper.depth_unit
            and lower.depth_unit
            and upper.depth_unit.strip().lower() != lower.depth_unit.strip().lower()
        ):
            continue

        if upper.bottom_depth is not None and lower.top_depth < upper.bottom_depth:
            findings.append(
                CandidateContradiction(
                    rule_code="RULE-STRAT-ORDER-001",
                    category="STRATIGRAPHIC_ORDER_CONTRADICTION",
                    outcome_classification=ContradictionOutcome.POTENTIAL_DATA_INCONSISTENCY,
                    severity=SeverityLevel.HIGH,
                    well_or_interval=f"{well_identifier} :: {upper.formation_name} / {lower.formation_name}",
                    first_source_location_id=upper.source_location_id,
                    second_source_location_id=lower.source_location_id,
                    affected_claim_ids=[],
                    first_value_raw=f"{upper.formation_name} base={upper.bottom_depth}",
                    second_value_raw=f"{lower.formation_name} top={lower.top_depth}",
                    units=upper.depth_unit,
                    explanation=(
                        f"Overlapping depth intervals in well '{well_identifier}': '{upper.formation_name}' base "
                        f"({upper.bottom_depth}) is deeper than '{lower.formation_name}' top ({lower.top_depth})."
                    ),
                    possible_geological_causes=[
                        "Duplicate or overlapping formation pick across multiple reports.",
                        "Thrust fault repetition or overturned fold limb.",
                    ],
                )
            )

        rank_upper = formation_rank_map.get(upper.formation_name.strip().lower())
        rank_lower = formation_rank_map.get(lower.formation_name.strip().lower())
        if rank_upper is not None and rank_lower is not None and rank_upper > rank_lower:
            findings.append(
                CandidateContradiction(
                    rule_code="RULE-STRAT-ORDER-001",
                    category="STRATIGRAPHIC_ORDER_CONTRADICTION",
                    outcome_classification=ContradictionOutcome.GEOLOGICAL_INTERPRETATION_DISAGREEMENT,
                    severity=SeverityLevel.CRITICAL,
                    well_or_interval=f"{well_identifier} :: {upper.formation_name} over {lower.formation_name}",
                    first_source_location_id=upper.source_location_id,
                    second_source_location_id=lower.source_location_id,
                    affected_claim_ids=[],
                    first_value_raw=f"{upper.formation_name} (rank {rank_upper}, top={upper.top_depth})",
                    second_value_raw=f"{lower.formation_name} (rank {rank_lower}, top={lower.top_depth})",
                    units=upper.depth_unit,
                    explanation=(
                        f"Stratigraphic order reversal in well '{well_identifier}': older formation '{upper.formation_name}' "
                        f"at {upper.top_depth} overlies younger formation '{lower.formation_name}' at {lower.top_depth}."
                    ),
                    possible_geological_causes=[
                        "Reverse or thrust fault repetition (e.g., toe-thrust or inverted rift structure).",
                        "Overturned stratigraphic limb.",
                        "Misidentified formation top or biostratigraphic zone.",
                    ],
                )
            )

    return findings
