from datetime import datetime, timezone
from uuid import UUID
from sqlalchemy.orm import Session

from app.core.enums import (
    ClaimClassification,
    ContradictionOutcome,
    PetroleumSystemElementType,
    ProcessingStatus,
    QualitativeStatus,
    ReviewStatus,
    SeverityLevel,
)
from app.models.knowledge import FormationRecord
from app.models.operational import (
    AnalysisRun,
    ClaimEvidence,
    Contradiction,
    Document,
    ExtractedRecord,
    GeologicalClaim,
    GeologicalRule,
    Prospect,
    RuleVersion,
    Well,
    WellInterval,
)
from app.services.validation.rules_stratigraphy import (
    CandidateContradiction,
    check_stratigraphic_order_and_depths,
)

RULE_DEFINITIONS = [
    ("RULE-STRAT-ORDER-001", "STRATIGRAPHY", "Stratigraphic Superposition & Interval Geometry Check", "v1.0.0", "rules_stratigraphy.py"),
    ("RULE-DEPTH-UNIT-002", "UNITS_AND_DATUMS", "Depth Unit & Reference Datum Consistency Check", "v1.0.0", "rules_stratigraphy.py"),
    ("RULE-CHRONO-BIO-003", "CHRONOSTRATIGRAPHY", "Age / Biostratigraphic Zone vs Formation Check", "v1.0.0", "rule_engine.py"),
    ("RULE-CLAIM-EVID-004", "EVIDENCE_COMPLETENESS", "Unsupported Claim & Unlinked Assumption Check", "v1.0.0", "rule_engine.py"),
    ("RULE-SEAL-TRAP-005", "SEAL_AND_TRAP", "Trap Closure & Top/Fault Seal Evidence Check", "v1.0.0", "rule_engine.py"),
    ("RULE-SOURCE-MAT-006", "SOURCE_AND_MATURITY", "Source Rock & Thermal Maturity Calibration Check", "v1.0.0", "rule_engine.py"),
    ("RULE-PRES-TIMING-007", "TIMING_AND_PRESERVATION", "Charge Timing & Post-Entrapment Breach Check", "v1.0.0", "rule_engine.py"),
    ("RULE-PROVENANCE-008", "DATA_PROVENANCE", "Source Location & OCR/Unit Human-Check Verification", "v1.0.0", "rule_engine.py"),
]


def ensure_rule_catalog(db: Session) -> dict[str, RuleVersion]:
    version_map: dict[str, RuleVersion] = {}
    for code, cat, name, ver_tag, impl in RULE_DEFINITIONS:
        rule = db.query(GeologicalRule).filter(GeologicalRule.rule_code == code).first()
        if not rule:
            rule = GeologicalRule(rule_code=code, category=cat, name=name, description=name, is_active=True)
            db.add(rule)
            db.flush()

        rv = (
            db.query(RuleVersion)
            .filter(RuleVersion.rule_id == rule.id, RuleVersion.version_tag == ver_tag)
            .first()
        )
        if not rv:
            rv = RuleVersion(rule_id=rule.id, version_tag=ver_tag, implementation_ref=impl, parameters_schema={})
            db.add(rv)
            db.flush()
        version_map[code] = rv
    return version_map


def run_deterministic_validation(db: Session, *, prospect: Prospect, triggered_by_user_id: UUID) -> AnalysisRun:
    rule_versions = ensure_rule_catalog(db)

    run = AnalysisRun(
        organisation_id=prospect.organisation_id,
        prospect_id=prospect.id,
        run_type="DETERMINISTIC_VALIDATION",
        triggered_by=triggered_by_user_id,
        executed_rule_versions=[{"rule_code": k, "version": v.version_tag} for k, v in rule_versions.items()],
        status=ProcessingStatus.COMPLETED,
    )
    db.add(run)
    db.flush()

    # Clear prior unreviewed deterministic contradictions from earlier runs on this prospect
    db.query(Contradiction).filter(
        Contradiction.prospect_id == prospect.id,
        Contradiction.organisation_id == prospect.organisation_id,
        Contradiction.review_status == ReviewStatus.UNREVIEWED,
    ).delete(synchronize_session=False)

    candidates: list[CandidateContradiction] = []

    # Build formation rank lookup from curated Environment B library if basin_profile is linked
    formation_rank_map: dict[str, int] = {}
    formation_age_map: dict[str, str] = {}
    if prospect.basin_profile_id:
        fms = (
            db.query(FormationRecord)
            .filter(
                FormationRecord.basin_profile_id == prospect.basin_profile_id,
                FormationRecord.review_status.in_([ReviewStatus.APPROVED, ReviewStatus.CONDITIONALLY_APPROVED]),
            )
            .all()
        )
        for fm in fms:
            if fm.stratigraphic_rank_order is not None:
                formation_rank_map[fm.formation_name.strip().lower()] = fm.stratigraphic_rank_order
                for alias in fm.recognized_aliases or []:
                    formation_rank_map[str(alias).strip().lower()] = fm.stratigraphic_rank_order
            if fm.age_range:
                formation_age_map[fm.formation_name.strip().lower()] = fm.age_range.lower()

    # Checks A, B & C across all wells & intervals
    wells = (
        db.query(Well)
        .filter(Well.prospect_id == prospect.id, Well.organisation_id == prospect.organisation_id, Well.deleted_at.is_(None))
        .all()
    )
    for well in wells:
        intervals = (
            db.query(WellInterval)
            .filter(
                WellInterval.well_id == well.id,
                WellInterval.organisation_id == prospect.organisation_id,
                WellInterval.deleted_at.is_(None),
            )
            .all()
        )
        candidates.extend(
            check_stratigraphic_order_and_depths(
                well_identifier=well.well_identifier,
                intervals=intervals,
                formation_rank_map=formation_rank_map,
            )
        )
        # Check C: Chronostratigraphy vs formation reference age
        for iv in intervals:
            ref_age = formation_age_map.get(iv.formation_name.strip().lower())
            if ref_age and iv.reported_age:
                rep_lower = iv.reported_age.strip().lower()
                if rep_lower not in ref_age and ref_age not in rep_lower:
                    candidates.append(
                        CandidateContradiction(
                            rule_code="RULE-CHRONO-BIO-003",
                            category="CHRONOSTRATIGRAPHIC_AGE_MISMATCH",
                            outcome_classification=ContradictionOutcome.GEOLOGICAL_INTERPRETATION_DISAGREEMENT,
                            severity=SeverityLevel.MODERATE,
                            well_or_interval=f"{well.well_identifier} :: {iv.formation_name}",
                            first_source_location_id=iv.source_location_id,
                            second_source_location_id=None,
                            affected_claim_ids=[],
                            first_value_raw=f"reported_age={iv.reported_age}",
                            second_value_raw=f"reference_age={ref_age}",
                            units=None,
                            explanation=(
                                f"Reported age '{iv.reported_age}' for formation '{iv.formation_name}' in well "
                                f"'{well.well_identifier}' differs from curated regional age range '{ref_age}'."
                            ),
                            possible_geological_causes=[
                                "Diachronous formation boundary across depobelts (common in Niger Delta Akata/Agbada/Benin).",
                                "Reworked palynomorphs/foraminifera or biostratigraphic zone re-interpretation.",
                            ],
                        )
                    )

    # Check D, E, F, G: GeologicalClaims evidence completeness & petroleum system gaps
    claims = (
        db.query(GeologicalClaim)
        .filter(
            GeologicalClaim.prospect_id == prospect.id,
            GeologicalClaim.organisation_id == prospect.organisation_id,
            GeologicalClaim.deleted_at.is_(None),
        )
        .all()
    )
    covered_ps_elements: set[PetroleumSystemElementType] = set()
    for cl in claims:
        if cl.petroleum_system_element:
            covered_ps_elements.add(cl.petroleum_system_element)

        links = db.query(ClaimEvidence).filter(ClaimEvidence.claim_id == cl.id).all()
        supporting = [lk for lk in links if lk.relationship_role == "SUPPORTING"]
        opposing = [lk for lk in links if lk.relationship_role == "OPPOSING"]

        if opposing and supporting:
            cl.qualitative_status = QualitativeStatus.MIXED_EVIDENCE
        elif opposing and not supporting:
            cl.qualitative_status = QualitativeStatus.CONTRADICTED
        elif supporting:
            cl.qualitative_status = QualitativeStatus.SUPPORTED
        else:
            cl.qualitative_status = QualitativeStatus.INSUFFICIENT_EVIDENCE

        if not supporting:
            severity = (
                SeverityLevel.HIGH
                if cl.claim_classification in {ClaimClassification.OBSERVATION, ClaimClassification.INTERPRETATION}
                else SeverityLevel.MODERATE
            )
            candidates.append(
                CandidateContradiction(
                    rule_code="RULE-CLAIM-EVID-004",
                    category="UNSUPPORTED_CLAIM_OR_ASSUMPTION",
                    outcome_classification=ContradictionOutcome.MISSING_INFORMATION,
                    severity=severity,
                    well_or_interval=cl.stratigraphic_applicability or cl.geological_element,
                    first_source_location_id=None,
                    second_source_location_id=None,
                    affected_claim_ids=[str(cl.id)],
                    first_value_raw=f"classification={cl.claim_classification.value}",
                    second_value_raw="supporting_evidence_count=0",
                    units=None,
                    explanation=(
                        f"Claim '{cl.claim_text[:140]}' ({cl.claim_classification.value}) has zero linked supporting "
                        f"evidence items in the Evidence Ledger."
                    ),
                    possible_geological_causes=[
                        "Underlying well log, seismic horizon, or geochemical report has not yet been ingested or linked.",
                    ],
                )
            )

    # Check E / F / G: Missing critical petroleum system elements
    element_rule_map = {
        PetroleumSystemElementType.TRAP: ("RULE-SEAL-TRAP-005", "No geological claims or evidence registered for Trap geometry/closure."),
        PetroleumSystemElementType.SEAL: ("RULE-SEAL-TRAP-005", "No geological claims or evidence registered for Top Seal or Fault Seal integrity."),
        PetroleumSystemElementType.SOURCE_ROCK: ("RULE-SOURCE-MAT-006", "No geological claims or evidence registered for Source Rock presence/TOC/kerogen."),
        PetroleumSystemElementType.THERMAL_MATURITY: ("RULE-SOURCE-MAT-006", "No geological claims or evidence registered for Thermal Maturity / burial window."),
        PetroleumSystemElementType.TIMING: ("RULE-PRES-TIMING-007", "No geological claims or evidence registered for Trap-vs-Charge relative timing."),
        PetroleumSystemElementType.PRESERVATION: ("RULE-PRES-TIMING-007", "No geological claims or evidence registered for Post-Entrapment Preservation / uplift / biodegradation."),
    }
    for elem, (rcode, msg) in element_rule_map.items():
        if elem not in covered_ps_elements:
            candidates.append(
                CandidateContradiction(
                    rule_code=rcode,
                    category="MISSING_PETROLEUM_SYSTEM_EVIDENCE",
                    outcome_classification=ContradictionOutcome.MISSING_INFORMATION,
                    severity=SeverityLevel.HIGH,
                    well_or_interval=elem.value,
                    first_source_location_id=None,
                    second_source_location_id=None,
                    affected_claim_ids=[],
                    first_value_raw=f"element={elem.value}",
                    second_value_raw="registered_claims=0",
                    units=None,
                    explanation=msg,
                    possible_geological_causes=[
                        f"Prospect evaluation dossier currently lacks explicit evidence covering {elem.value}.",
                    ],
                )
            )

    # Check H: Provenance & unverified extraction quality
    needs_human_count = (
        db.query(ExtractedRecord)
        .filter(
            ExtractedRecord.prospect_id == prospect.id,
            ExtractedRecord.organisation_id == prospect.organisation_id,
            ExtractedRecord.extraction_quality_label == "REQUIRES_HUMAN_CHECK",
            ExtractedRecord.review_status == ReviewStatus.UNREVIEWED,
        )
        .count()
    )
    if needs_human_count > 0:
        candidates.append(
            CandidateContradiction(
                rule_code="RULE-PROVENANCE-008",
                category="PROVENANCE_AND_EXTRACTION_QUALITY",
                outcome_classification=ContradictionOutcome.MISSING_INFORMATION,
                severity=SeverityLevel.MODERATE,
                well_or_interval="Ingested Prospect Records",
                first_source_location_id=None,
                second_source_location_id=None,
                affected_claim_ids=[],
                first_value_raw=f"requires_human_check_records={needs_human_count}",
                second_value_raw="verified_records=0",
                units=None,
                explanation=(
                    f"{needs_human_count} extracted record(s) from OCR or unit-incomplete tables are flagged "
                    f"REQUIRES_HUMAN_CHECK and await geoscientist verification."
                ),
                possible_geological_causes=["Scanned PDF pages or spreadsheets lacking explicit depth/measurement units."],
            )
        )

    doc_count = (
        db.query(Document)
        .filter(Document.prospect_id == prospect.id, Document.organisation_id == prospect.organisation_id, Document.deleted_at.is_(None))
        .count()
    )
    if doc_count == 0:
        candidates.append(
            CandidateContradiction(
                rule_code="RULE-PROVENANCE-008",
                category="PROVENANCE_AND_EXTRACTION_QUALITY",
                outcome_classification=ContradictionOutcome.MISSING_INFORMATION,
                severity=SeverityLevel.HIGH,
                well_or_interval="Prospect Document Repository",
                first_source_location_id=None,
                second_source_location_id=None,
                affected_claim_ids=[],
                first_value_raw="uploaded_documents=0",
                second_value_raw="minimum_primary_documents>=1",
                units=None,
                explanation="Prospect has zero uploaded primary geological documents in Environment A.",
                possible_geological_causes=["No well reports, formation-top tables, or seismic summaries uploaded yet."],
            )
        )

    for cand in candidates:
        rv = rule_versions[cand.rule_code]
        db.add(
            Contradiction(
                organisation_id=prospect.organisation_id,
                prospect_id=prospect.id,
                analysis_run_id=run.id,
                rule_version_id=rv.id,
                category=cand.category,
                outcome_classification=cand.outcome_classification,
                severity=cand.severity,
                well_or_interval=cand.well_or_interval,
                first_source_location_id=cand.first_source_location_id,
                second_source_location_id=cand.second_source_location_id,
                affected_claim_ids=cand.affected_claim_ids,
                first_value_raw=cand.first_value_raw,
                second_value_raw=cand.second_value_raw,
                units=cand.units,
                explanation=cand.explanation,
                possible_geological_causes=cand.possible_geological_causes,
                review_status=ReviewStatus.UNREVIEWED,
            )
        )

    run.completed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(run)
    return run
