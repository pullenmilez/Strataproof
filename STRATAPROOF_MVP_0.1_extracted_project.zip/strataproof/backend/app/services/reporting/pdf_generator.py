import hashlib
import html
from datetime import datetime, timezone
from uuid import UUID
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.enums import ReviewStatus
from app.models.knowledge import BasinProfile, KnowledgeSource
from app.models.operational import (
    AnalysisRun,
    Assessment,
    AssessmentReference,
    AssessmentVersion,
    Contradiction,
    Document,
    DocumentVersion,
    EvidenceItem,
    FalsificationHypothesis,
    GeologicalClaim,
    Investigation,
    InvestigationRanking,
    Organisation,
    PetroleumSystemElement,
    Project,
    Prospect,
    User,
    Well,
)
from app.services.storage import PrivateObjectStorageService


def _esc(val) -> str:
    return html.escape(str(val)) if val is not None else "—"


def generate_prospect_assessment_pdf(
    db: Session,
    *,
    prospect: Prospect,
    generated_by_user: User,
    title: str,
    scope_and_limitations: str,
) -> AssessmentVersion:
    org = db.query(Organisation).filter(Organisation.id == prospect.organisation_id).first()
    project = db.query(Project).filter(Project.id == prospect.project_id).first()
    basin = db.query(BasinProfile).filter(BasinProfile.id == prospect.basin_profile_id).first()

    docs = db.query(Document).filter(Document.prospect_id == prospect.id, Document.deleted_at.is_(None)).all()
    doc_versions = (
        db.query(DocumentVersion)
        .join(Document, Document.id == DocumentVersion.document_id)
        .filter(Document.prospect_id == prospect.id)
        .all()
    )
    wells = db.query(Well).filter(Well.prospect_id == prospect.id, Well.deleted_at.is_(None)).all()
    claims = db.query(GeologicalClaim).filter(GeologicalClaim.prospect_id == prospect.id, GeologicalClaim.deleted_at.is_(None)).all()
    evidences = db.query(EvidenceItem).filter(EvidenceItem.prospect_id == prospect.id, EvidenceItem.deleted_at.is_(None)).all()
    contradictions = db.query(Contradiction).filter(Contradiction.prospect_id == prospect.id, Contradiction.deleted_at.is_(None)).all()
    ps_elements = db.query(PetroleumSystemElement).filter(PetroleumSystemElement.prospect_id == prospect.id).all()
    hypotheses = db.query(FalsificationHypothesis).filter(FalsificationHypothesis.prospect_id == prospect.id, FalsificationHypothesis.deleted_at.is_(None)).all()
    inv_rows = (
        db.query(Investigation, InvestigationRanking)
        .join(InvestigationRanking, InvestigationRanking.investigation_id == Investigation.id)
        .filter(Investigation.prospect_id == prospect.id)
        .order_by(InvestigationRanking.priority_rank.asc())
        .all()
    )
    runs = db.query(AnalysisRun).filter(AnalysisRun.prospect_id == prospect.id).order_by(AnalysisRun.started_at.desc()).all()

    referenced_k_ids: set[str] = set()
    for h in hypotheses:
        for kid in h.knowledge_source_ids or []:
            referenced_k_ids.add(str(kid))
    knowledge_sources = (
        db.query(KnowledgeSource)
        .filter(KnowledgeSource.verification_status.in_([ReviewStatus.APPROVED, ReviewStatus.CONDITIONALLY_APPROVED, ReviewStatus.DISPUTED]))
        .all()
    )

    generated_at = datetime.now(timezone.utc)
    obs_claims = [c for c in claims if c.claim_classification.value == "OBSERVATION"]
    interp_claims = [c for c in claims if c.claim_classification.value == "INTERPRETATION"]
    assump_claims = [c for c in claims if c.claim_classification.value == "ASSUMPTION"]
    pred_claims = [c for c in claims if c.claim_classification.value == "PREDICTION"]

    html_content = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<style>
  @page {{ size: A4; margin: 18mm 16mm 18mm 16mm; }}
  body {{ font-family: 'DejaVu Sans', Arial, sans-serif; color: #1e293b; font-size: 9.5pt; line-height: 1.45; }}
  .cover {{ border-bottom: 3px solid #0f2942; padding-bottom: 14px; margin-bottom: 18px; }}
  .brand {{ color: #b45309; font-weight: bold; letter-spacing: 1.2px; font-size: 9pt; text-transform: uppercase; }}
  h1 {{ color: #0f2942; font-size: 18pt; margin: 4px 0 6px 0; }}
  h2 {{ color: #0f2942; font-size: 11.5pt; border-bottom: 1px solid #cbd5e1; padding-bottom: 3px; margin-top: 16px; page-break-after: avoid; }}
  table {{ width: 100%; border-collapse: collapse; margin: 8px 0 12px 0; font-size: 8.5pt; }}
  th {{ background-color: #0f2942; color: #ffffff; text-align: left; padding: 6px; border: 1px solid #0f2942; }}
  td {{ padding: 5px 6px; border: 1px solid #cbd5e1; vertical-align: top; }}
  .notice {{ background: #fffbeb; border-left: 4px solid #b45309; padding: 8px 10px; margin: 8px 0; font-size: 8.8pt; }}
  .badge {{ display: inline-block; padding: 2px 5px; background: #e2e8f0; border-radius: 3px; font-weight: bold; font-size: 7.5pt; }}
</style>
</head>
<body>

<div class="cover">
  <div class="brand">STRATAPROOF — GEOLOGICAL EVIDENCE-ASSURANCE & FALSIFICATION REPORT</div>
  <h1>{_esc(title)}</h1>
  <div><strong>Organisation:</strong> {_esc(org.name if org else '')} &nbsp;|&nbsp;
       <strong>Project:</strong> {_esc(project.name if project else '')} ({_esc(project.code if project else '')})</div>
  <div><strong>Prospect:</strong> {_esc(prospect.name)} &nbsp;|&nbsp;
       <strong>Basin / Country:</strong> {_esc(prospect.basin_name)}, {_esc(prospect.country)} &nbsp;|&nbsp;
       <strong>Block/Licence:</strong> {_esc(prospect.block_or_licence)}</div>
  <div><strong>Generated UTC:</strong> {generated_at.strftime('%Y-%m-%d %H:%M:%S UTC')} &nbsp;|&nbsp;
       <strong>Prepared By:</strong> {_esc(generated_by_user.full_name)}</div>
</div>

<h2>1. Executive Overview & Decision-Support Mandate</h2>
<p>This assurance dossier evaluates the geological evidence base, internal consistency, and principal failure mechanisms for prospect <strong>{_esc(prospect.name)}</strong> in the <strong>{_esc(prospect.basin_name)}</strong> ({_esc(prospect.country)}). It summarizes {len(docs)} uploaded document(s), {len(wells)} well record(s), {len(claims)} geological claim(s), {len(contradictions)} detected contradiction/gap item(s), {len(ps_elements)} evaluated petroleum-system elements, and {len(inv_rows)} prioritized discriminating investigation(s).</p>

<h2>2. Scope, Methodology, and Explicit Limitations</h2>
<div class="notice">{_esc(scope_and_limitations)}<br/><strong>Strict Scientific Notice:</strong> STRATAPROOF reports qualitative evidence-support categories only. It does not generate discovery probabilities, hydrocarbon volume estimates, or fabricated numerical confidence scores.</div>

<h2>3. Prospect Identity & Geological Setting</h2>
<p><strong>Target Formations:</strong> {_esc(', '.join(prospect.target_formations or []) or 'Not explicitly specified')}<br/>
<strong>Sub-basin / Province:</strong> {_esc(prospect.sub_basin_or_province)}<br/>
<strong>Prospect Description:</strong> {_esc(prospect.description)}</p>

<h2>4. Regional Basin Context (Curated Verified Knowledge Library)</h2>
<p><strong>Basin Category:</strong> {_esc(basin.basin_category if basin else 'Unlinked basin profile')}<br/>
<strong>Tectonic Summary:</strong> {_esc(basin.tectonic_summary if basin else 'No approved basin profile linked.')}<br/>
<strong>Stratigraphic Overview:</strong> {_esc(basin.stratigraphic_overview if basin else '—')}<br/>
<strong>Regional Known Uncertainties:</strong> {_esc(basin.known_uncertainties_and_gaps if basin else '—')}</p>

<h2>5. Data Inventory & Document Provenance Register (Environment A)</h2>
<table>
  <tr><th>Document Title</th><th>Type</th><th>Filename</th><th>SHA-256 Checksum</th><th>Version</th></tr>
  {''.join(f"<tr><td>{_esc(d.title)}</td><td>{_esc(d.document_type)}</td><td>{_esc(dv.original_filename)}</td><td><code>{_esc(dv.sha256_checksum[:24])}...</code></td><td>v{dv.version_number}</td></tr>" for d in docs for dv in doc_versions if dv.document_id == d.id) or "<tr><td colspan='5'>No primary documents uploaded.</td></tr>"}
</table>

<h2>6. Well & Interval Provenance Summary</h2>
<table>
  <tr><th>Well Identifier</th><th>Total Depth (Raw)</th><th>Unit</th><th>Datum</th><th>Coordinate System</th></tr>
  {''.join(f"<tr><td>{_esc(w.well_identifier)}</td><td>{_esc(w.total_depth_raw)}</td><td>{_esc(w.depth_unit)}</td><td>{_esc(w.depth_datum)}</td><td>{_esc(w.coordinate_system)}</td></tr>" for w in wells) or "<tr><td colspan='5'>No structured wells registered.</td></tr>"}
</table>

<h2>7. Epistemic Classification Summary (Observations vs. Interpretations, Assumptions & Predictions)</h2>
<ul>
  <li><strong>OBSERVATION ({len(obs_claims)}):</strong> Direct measurements or primary records.</li>
  <li><strong>INTERPRETATION ({len(interp_claims)}):</strong> Geoscientist inferences derived from observations.</li>
  <li><strong>ASSUMPTION ({len(assump_claims)}):</strong> Unverified working premises requiring testing.</li>
  <li><strong>PREDICTION ({len(pred_claims)}):</strong> Forward prognoses for undrilled targets.</li>
</ul>

<h2>8. Master Geological Evidence Ledger</h2>
<table>
  <tr><th>Element</th><th>Class</th><th>Claim Statement</th><th>Qualitative Status</th><th>Review Status</th></tr>
  {''.join(f"<tr><td>{_esc(c.geological_element)}</td><td><span class='badge'>{_esc(c.claim_classification.value)}</span></td><td>{_esc(c.claim_text)}</td><td>{_esc(c.qualitative_status.value)}</td><td>{_esc(c.review_status.value)}</td></tr>" for c in claims) or "<tr><td colspan='5'>No geological claims recorded.</td></tr>"}
</table>

<h2>9. Primary Documentary Evidence Items</h2>
<table>
  <tr><th>Type</th><th>Subject</th><th>Well / Formation / Interval</th><th>Description</th></tr>
  {''.join(f"<tr><td>{_esc(e.evidence_type)}</td><td>{_esc(e.geological_subject)}</td><td>{_esc(e.well_identifier)} / {_esc(e.formation)} ({_esc(e.depth_interval_raw)} {_esc(e.depth_unit or '')})</td><td>{_esc(e.evidence_description)}</td></tr>" for e in evidences) or "<tr><td colspan='4'>No evidence items recorded.</td></tr>"}
</table>

<h2>10. Deterministic Consistency & Contradiction Findings</h2>
<table>
  <tr><th>Category</th><th>Outcome</th><th>Severity</th><th>Raw Values</th><th>Explanation</th></tr>
  {''.join(f"<tr><td>{_esc(ct.category)}</td><td>{_esc(ct.outcome_classification.value)}</td><td>{_esc(ct.severity.value)}</td><td>{_esc(ct.first_value_raw)} vs {_esc(ct.second_value_raw)}</td><td>{_esc(ct.explanation)}</td></tr>" for ct in contradictions) or "<tr><td colspan='5'>No contradictions detected.</td></tr>"}
</table>

<h2>11. Petroleum System 8-Element Assurance Matrix</h2>
<table>
  <tr><th>Element</th><th>Qualitative Support Status</th><th>Rationale</th><th>Missing Evidence</th></tr>
  {''.join(f"<tr><td><strong>{_esc(ps.element_type.value)}</strong></td><td>{_esc(ps.qualitative_status.value)}</td><td>{_esc(ps.status_rationale)}</td><td>{_esc('; '.join(ps.missing_evidence_summary or []))}</td></tr>" for ps in ps_elements) or "<tr><td colspan='4'>Petroleum system falsification analysis not yet executed.</td></tr>"}
</table>

<h2>12. Source Rock & Thermal Maturity Evaluation</h2>
<p>Evaluated independently under the Petroleum System Assurance Matrix above. Any uncalibrated TOC, kerogen typing, or vitrinite reflectance (%Ro) gaps remain explicitly flagged as INSUFFICIENT_EVIDENCE until primary geochemical data are linked.</p>

<h2>13. Reservoir, Top Seal & Fault Seal Evaluation</h2>
<p>Evaluated independently against well-log, core, and structural fault-juxtaposition records. Absence of capillary entry pressure or Shale Gouge Ratio (SGR) calibration is retained as an explicit seal failure hypothesis.</p>

<h2>14. Trap Geometry, Migration Pathway, Timing & Preservation Evaluation</h2>
<p>Structural closure velocity sensitivity, fetch-area migration continuity, trap-versus-charge relative timing, and post-entrapment uplift/biodegradation risks are tracked as distinct elements without masking weak links.</p>

<h2>15. Adversarial Falsification Hypotheses ("How Could This Prospect Fail?")</h2>
<table>
  <tr><th>Applicability</th><th>Proposed Failure Mechanism</th><th>Review Status</th><th>Confidence Rationale</th></tr>
  {''.join(f"<tr><td>{_esc(h.geological_applicability)}</td><td>{_esc(h.proposed_failure_mechanism)}</td><td>{_esc(h.review_status.value)}</td><td>{_esc(h.confidence_rationale)}</td></tr>" for h in hypotheses) or "<tr><td colspan='4'>No falsification hypotheses generated.</td></tr>"}
</table>

<h2>16. Information Gaps & Unverified Working Assumptions</h2>
<p>All claims lacking linked supporting EvidenceItems and all OCR/unit-incomplete records flagged <code>REQUIRES_HUMAN_CHECK</code> are itemized in Sections 8 and 10 for mandatory geoscientist resolution prior to drill-decision gate review.</p>

<h2>17. Prioritized Discriminating Investigations</h2>
<table>
  <tr><th>Rank</th><th>Relevance</th><th>Investigation</th><th>Discriminating Objective</th><th>Required Data / Test</th></tr>
  {''.join(f"<tr><td>#{rk.priority_rank}</td><td>{_esc(rk.decision_relevance)}</td><td><strong>{_esc(inv.title)}</strong></td><td>{_esc(inv.discriminating_objective)}</td><td>{_esc(inv.required_data_or_test)}</td></tr>" for inv, rk in inv_rows) or "<tr><td colspan='5'>No investigations ranked yet.</td></tr>"}
</table>

<h2>18. Human Review & Sign-Off Governance Status</h2>
<p>Total Claims: {len(claims)} | Approved Claims: {sum(1 for c in claims if c.review_status == ReviewStatus.APPROVED)} | Pending Review: {sum(1 for c in claims if c.review_status != ReviewStatus.APPROVED)}. AI-suggested hypotheses remain labeled <code>AI_SUGGESTED_PENDING_REVIEW</code> until signed off by a Lead Geologist or Reviewer.</p>

<h2>19. Customer Document References (Environment A)</h2>
<ul>
  {''.join(f"<li>{_esc(d.title)} — {_esc(dv.original_filename)} (v{dv.version_number}, SHA-256: {_esc(dv.sha256_checksum)})</li>" for d in docs for dv in doc_versions if dv.document_id == d.id) or "<li>None</li>"}
</ul>

<h2>20. Verified Geological Knowledge References & Execution Lineage (Environment B & C)</h2>
<ul>
  {''.join(f"<li>{_esc(ks.authors_or_institution)} ({_esc(ks.publication_year)}). <em>{_esc(ks.title)}</em>. [{_esc(ks.verification_status.value)}]</li>" for ks in knowledge_sources) or "<li>No external regional knowledge sources linked.</li>"}
</ul>
<p><strong>Analysis Runs Recorded:</strong> {len(runs)} deterministic/falsification execution(s) logged in immutable audit lineage.</p>

</body>
</html>
"""

    from weasyprint import HTML

    pdf_bytes = HTML(string=html_content).write_pdf()
    pdf_sha256 = hashlib.sha256(pdf_bytes).hexdigest()

    assessment = (
        db.query(Assessment)
        .filter(Assessment.prospect_id == prospect.id, Assessment.organisation_id == prospect.organisation_id)
        .first()
    )
    if not assessment:
        assessment = Assessment(
            organisation_id=prospect.organisation_id,
            project_id=prospect.project_id,
            prospect_id=prospect.id,
            title=title,
            current_version=1,
            created_by=generated_by_user.id,
        )
        db.add(assessment)
        db.flush()
        ver_num = 1
    else:
        assessment.current_version += 1
        ver_num = assessment.current_version

    storage = PrivateObjectStorageService()
    s3_key = (
        f"org/{prospect.organisation_id}/projects/{prospect.project_id}/prospects/{prospect.id}/"
        f"assessments/{assessment.id}_v{ver_num}_{pdf_sha256[:12]}.pdf"
    )
    storage.client.put_object(
        Bucket=settings.S3_BUCKET_CUSTOMER_DOCS,
        Key=s3_key,
        Body=pdf_bytes,
        ContentType="application/pdf",
        Metadata={"organisation_id": str(prospect.organisation_id), "sha256": pdf_sha256},
    )

    av = AssessmentVersion(
        organisation_id=prospect.organisation_id,
        assessment_id=assessment.id,
        version_number=ver_num,
        scope_and_limitations=scope_and_limitations,
        snapshot_data={
            "prospect_id": str(prospect.id),
            "claims_count": len(claims),
            "contradictions_count": len(contradictions),
            "hypotheses_count": len(hypotheses),
            "investigations_count": len(inv_rows),
        },
        pdf_s3_key=s3_key,
        pdf_sha256=pdf_sha256,
        generated_by=generated_by_user.id,
        generated_at=generated_at,
    )
    db.add(av)
    db.flush()

    for dv in doc_versions:
        db.add(
            AssessmentReference(
                organisation_id=prospect.organisation_id,
                assessment_version_id=av.id,
                reference_type="CUSTOMER_DOCUMENT",
                document_version_id=dv.id,
                citation_label=f"{dv.original_filename} (v{dv.version_number}, SHA-256={dv.sha256_checksum})",
            )
        )
    for ks in knowledge_sources:
        db.add(
            AssessmentReference(
                organisation_id=prospect.organisation_id,
                assessment_version_id=av.id,
                reference_type="VERIFIED_KNOWLEDGE_SOURCE",
                knowledge_source_id=ks.id,
                citation_label=f"{ks.authors_or_institution} ({ks.publication_year}): {ks.title}",
            )
        )

    db.commit()
    db.refresh(av)
    return av
