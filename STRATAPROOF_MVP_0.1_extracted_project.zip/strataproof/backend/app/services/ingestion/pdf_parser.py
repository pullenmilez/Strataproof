import io
from dataclasses import dataclass, field
from pypdf import PdfReader


@dataclass
class ParsedPage:
    page_number: int
    text: str
    used_ocr: bool = False


@dataclass
class PDFParseResult:
    pages: list[ParsedPage] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def parse_pdf_document(pdf_bytes: bytes) -> PDFParseResult:
    result = PDFParseResult()
    reader = PdfReader(io.BytesIO(pdf_bytes))

    for idx, page in enumerate(reader.pages, start=1):
        extracted = (page.extract_text() or "").strip()
        used_ocr = False
        if len(extracted) < 25:
            try:
                from pdf2image import convert_from_bytes
                import pytesseract

                images = convert_from_bytes(pdf_bytes, first_page=idx, last_page=idx, dpi=200)
                if images:
                    ocr_text = (pytesseract.image_to_string(images[0]) or "").strip()
                    if ocr_text:
                        extracted = ocr_text
                        used_ocr = True
                        result.warnings.append(
                            f"Page {idx} extracted via OCR fallback; requires geologist verification (REQUIRES_HUMAN_CHECK)."
                        )
            except Exception as ocr_exc:
                result.warnings.append(
                    f"Page {idx} has minimal selectable text and OCR could not complete: {type(ocr_exc).__name__}."
                )

        if extracted:
            result.pages.append(ParsedPage(page_number=idx, text=extracted, used_ocr=used_ocr))
        else:
            result.warnings.append(f"Page {idx} yielded no extractable text.")

    return result
