import io
from dataclasses import dataclass, field
import lasio


@dataclass
class LASParseResult:
    well_header: dict = field(default_factory=dict)
    curves: list[dict] = field(default_factory=list)
    depth_start: float | None = None
    depth_stop: float | None = None
    depth_step: float | None = None
    depth_unit: str | None = None
    warnings: list[str] = field(default_factory=list)


def parse_las_bytes(las_bytes: bytes) -> LASParseResult:
    result = LASParseResult()
    text = las_bytes.decode("utf-8", errors="replace")
    las = lasio.read(io.StringIO(text))

    for item in las.well:
        result.well_header[item.mnemonic] = {
            "value": str(item.value) if item.value is not None else None,
            "unit": item.unit or None,
            "descr": item.descr or None,
        }

    strt = las.well.get("STRT")
    stop = las.well.get("STOP")
    step = las.well.get("STEP")
    result.depth_start = float(strt.value) if strt and strt.value not in (None, "") else None
    result.depth_stop = float(stop.value) if stop and stop.value not in (None, "") else None
    result.depth_step = float(step.value) if step and step.value not in (None, "") else None
    result.depth_unit = (strt.unit if strt and strt.unit else None)

    if not result.depth_unit:
        result.warnings.append("LAS ~Well STRT/STOP depth unit is blank; flagged REQUIRES_HUMAN_CHECK.")

    well_name_item = las.well.get("WELL")
    if not well_name_item or not str(well_name_item.value or "").strip():
        result.warnings.append("LAS ~Well WELL mnemonic is empty; incomplete well identifier flagged.")

    for curve in las.curves:
        result.curves.append(
            {
                "mnemonic": curve.mnemonic,
                "unit": curve.unit or None,
                "description": curve.descr or None,
            }
        )
    return result
