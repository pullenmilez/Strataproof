import csv
import io
from dataclasses import dataclass, field
from openpyxl import load_workbook


@dataclass
class TabularRowRecord:
    sheet_name: str
    row_number: int
    raw_dict: dict
    has_missing_units: bool
    has_missing_well_id: bool


@dataclass
class TabularParseResult:
    rows: list[TabularRowRecord] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def _normalize_headers(headers: list) -> list[str]:
    return [str(h).strip().lower().replace(" ", "_") if h is not None else f"col_{i}" for i, h in enumerate(headers)]


def _inspect_row(sheet_name: str, row_num: int, row_dict: dict) -> TabularRowRecord:
    unit_keys = [k for k in row_dict if "unit" in k]
    well_keys = [k for k in row_dict if "well" in k]
    has_missing_units = not any(str(row_dict.get(k) or "").strip() for k in unit_keys)
    has_missing_well = not any(str(row_dict.get(k) or "").strip() for k in well_keys)
    return TabularRowRecord(
        sheet_name=sheet_name,
        row_number=row_num,
        raw_dict=row_dict,
        has_missing_units=has_missing_units,
        has_missing_well_id=has_missing_well,
    )


def parse_csv_bytes(csv_bytes: bytes) -> TabularParseResult:
    result = TabularParseResult()
    text = csv_bytes.decode("utf-8-sig", errors="replace")
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    if not rows:
        result.warnings.append("CSV file contains zero rows.")
        return result

    headers = _normalize_headers(rows[0])
    for idx, values in enumerate(rows[1:], start=2):
        if not any(v.strip() for v in values):
            continue
        row_dict = {headers[i]: (values[i].strip() if i < len(values) else None) for i in range(len(headers))}
        rec = _inspect_row("CSV", idx, row_dict)
        if rec.has_missing_units:
            result.warnings.append(f"Row {idx}: missing explicit depth/measurement unit; flagged REQUIRES_HUMAN_CHECK.")
        result.rows.append(rec)
    return result


def parse_xlsx_bytes(xlsx_bytes: bytes) -> TabularParseResult:
    result = TabularParseResult()
    wb = load_workbook(io.BytesIO(xlsx_bytes), data_only=True, read_only=True)
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        sheet_rows = list(ws.iter_rows(values_only=True))
        if not sheet_rows:
            continue
        headers = _normalize_headers(list(sheet_rows[0]))
        for idx, values in enumerate(sheet_rows[1:], start=2):
            if not any(v is not None and str(v).strip() != "" for v in values):
                continue
            row_dict = {
                headers[i]: (str(values[i]).strip() if i < len(values) and values[i] is not None else None)
                for i in range(len(headers))
            }
            rec = _inspect_row(sheet_name, idx, row_dict)
            if rec.has_missing_units:
                result.warnings.append(
                    f"Sheet '{sheet_name}' row {idx}: missing explicit unit; flagged REQUIRES_HUMAN_CHECK."
                )
            result.rows.append(rec)
    return result
