from dataclasses import dataclass
import httpx
from app.core.config import settings


@dataclass
class AIResponse:
    text: str
    model_used: str
    used_external_llm: bool


class PluggableAIProvider:
    """
    Vendor-neutral AI provider abstraction.
    - When AI_PROVIDER == 'disabled' or org authorization is False, executes deterministically with zero external calls.
    - Never permitted to fabricate geological measurements, probabilities, or unverified citations.
    """

    def __init__(self, org_ai_authorized: bool) -> None:
        self.org_ai_authorized = org_ai_authorized
        self.provider = (settings.AI_PROVIDER or "disabled").lower().strip()

    @property
    def is_external_enabled(self) -> bool:
        return self.org_ai_authorized and self.provider in {"openai", "anthropic", "gemini"} and bool(settings.AI_API_KEY)

    def synthesize_falsification_narrative(self, *, system_prompt: str, user_prompt: str, fallback_text: str) -> AIResponse:
        if not self.is_external_enabled:
            return AIResponse(
                text=fallback_text,
                model_used="deterministic-geological-synthesis-v1",
                used_external_llm=False,
            )

        try:
            if self.provider == "openai":
                resp = httpx.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={"Authorization": f"Bearer {settings.AI_API_KEY}"},
                    json={
                        "model": settings.AI_MODEL_NAME,
                        "temperature": 0.1,
                        "max_tokens": settings.AI_MAX_TOKENS,
                        "messages": [
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": user_prompt},
                        ],
                    },
                    timeout=settings.AI_REQUEST_TIMEOUT_SECONDS,
                )
                resp.raise_for_status()
                content = resp.json()["choices"][0]["message"]["content"]
                return AIResponse(text=content.strip(), model_used=settings.AI_MODEL_NAME, used_external_llm=True)
        except Exception:
            pass

        return AIResponse(
            text=fallback_text,
            model_used="deterministic-geological-synthesis-v1",
            used_external_llm=False,
        )
