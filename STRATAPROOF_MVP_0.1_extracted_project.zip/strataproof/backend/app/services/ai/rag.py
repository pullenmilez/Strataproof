from dataclasses import dataclass
from uuid import UUID
from sqlalchemy.orm import Session

from app.core.enums import ReviewStatus, SourceQualityTier
from app.models.knowledge import (
    GeologicalKnowledgeClaim,
    KnowledgeClaimSource,
    KnowledgeSource,
)


@dataclass
class VerifiedKnowledgeCitation:
    knowledge_claim_id: UUID
    knowledge_source_id: UUID | None
    citation_label: str
    claim_text: str
    limitations: str
    applicability_scope: str
    is_disputed: bool


def retrieve_verified_basin_knowledge(
    db: Session,
    *,
    country: str,
    basin_name: str,
    subject_keywords: list[str] | None = None,
    limit: int = 8,
) -> list[VerifiedKnowledgeCitation]:
    """
    Strict Environment B Grounded Retrieval Gate:
    - ONLY retrieves claims where review_status IN ('APPROVED', 'CONDITIONALLY_APPROVED', 'DISPUTED').
    - NEVER retrieves 'QUARANTINED_UNVERIFIED', 'UNREVIEWED', or 'REJECTED' records.
    """
    allowed_statuses = [
        ReviewStatus.APPROVED,
        ReviewStatus.CONDITIONALLY_APPROVED,
        ReviewStatus.DISPUTED,
    ]
    query = db.query(GeologicalKnowledgeClaim).filter(
        GeologicalKnowledgeClaim.country.ilike(country.strip()),
        GeologicalKnowledgeClaim.basin.ilike(f"%{basin_name.strip()}%"),
        GeologicalKnowledgeClaim.review_status.in_(allowed_statuses),
        GeologicalKnowledgeClaim.source_quality_tier != SourceQualityTier.QUARANTINED_UNVERIFIED,
        GeologicalKnowledgeClaim.deleted_at.is_(None),
    )

    claims = query.limit(limit * 3).all()
    results: list[VerifiedKnowledgeCitation] = []
    kw_lower = [k.lower() for k in (subject_keywords or []) if k]

    for kc in claims:
        if kw_lower:
            haystack = f"{kc.subject} {kc.claim_text} {kc.formation or ''}".lower()
            if not any(kw in haystack for kw in kw_lower):
                continue

        link = (
            db.query(KnowledgeClaimSource)
            .filter(KnowledgeClaimSource.knowledge_claim_id == kc.id)
            .first()
        )
        src = (
            db.query(KnowledgeSource)
            .filter(
                KnowledgeSource.id == link.knowledge_source_id,
                KnowledgeSource.verification_status.in_(allowed_statuses),
                KnowledgeSource.source_quality_tier != SourceQualityTier.QUARANTINED_UNVERIFIED,
            )
            .first()
            if link
            else None
        )
        if not src:
            # Never cite a knowledge claim whose underlying source is unverified or quarantined
            continue

        citation_label = (
            f"{src.authors_or_institution} ({src.publication_year or 'n.d.'}). "
            f"{src.title}. {src.publisher_or_journal or src.publication_type}."
        )
        results.append(
            VerifiedKnowledgeCitation(
                knowledge_claim_id=kc.id,
                knowledge_source_id=src.id,
                citation_label=citation_label,
                claim_text=kc.claim_text,
                limitations=kc.limitations,
                applicability_scope=kc.applicability_scope,
                is_disputed=kc.is_disputed,
            )
        )
        if len(results) >= limit:
            break

    return results
