from uuid import UUID
from sqlalchemy.orm import Session
from app.models.operational import AuditEvent


def record_audit_event(
    db: Session,
    *,
    organisation_id: UUID,
    actor_user_id: UUID | None,
    event_type: str,
    entity_type: str,
    entity_id: UUID | str,
    project_id: UUID | None = None,
    event_metadata: dict | None = None,
) -> AuditEvent:
    event = AuditEvent(
        organisation_id=organisation_id,
        project_id=project_id,
        actor_user_id=actor_user_id,
        event_type=event_type,
        entity_type=entity_type,
        entity_id=str(entity_id),
        event_metadata=event_metadata or {},
    )
    db.add(event)
    return event
