import hashlib
import os
import re
from dataclasses import dataclass
from uuid import UUID

import boto3
from botocore.client import Config
from fastapi import HTTPException, status

from app.core.config import settings

ALLOWED_EXTENSIONS = {".pdf", ".csv", ".xlsx", ".las"}


@dataclass(frozen=True)
class StoredObjectInfo:
    bucket: str
    object_key: str
    sha256_checksum: str
    file_size_bytes: int
    sanitized_filename: str
    detected_extension: str


def sanitize_filename(filename: str) -> str:
    base = os.path.basename(filename or "upload.bin")
    cleaned = re.sub(r"[^A-Za-z0-9._-]", "_", base)
    return cleaned[:200] or "upload.bin"


def validate_file_magic_and_extension(filename: str, content: bytes) -> str:
    max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
    if not content:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Uploaded file is empty.")
    if len(content) > max_bytes:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"File exceeds maximum allowed size of {settings.MAX_UPLOAD_SIZE_MB} MB.",
        )

    ext = os.path.splitext(filename.lower())[1]
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported file format '{ext}'. Permitted MVP formats: PDF, CSV, XLSX, LAS.",
        )

    header = content[:64]
    if ext == ".pdf" and not header.startswith(b"%PDF-"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid PDF magic header.")
    if ext == ".xlsx" and not header.startswith(b"PK\x03\x04"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid XLSX archive signature.")
    if ext in {".csv", ".las"}:
        if b"\x00" in content[:2048]:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Binary null bytes rejected in text file.")
        if ext == ".las" and b"~V" not in content[:4096].upper():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid LAS well-log file: missing ~Version (~V) section header.",
            )
    return ext


class PrivateObjectStorageService:
    def __init__(self) -> None:
        self.client = boto3.client(
            "s3",
            endpoint_url=settings.S3_ENDPOINT_URL,
            aws_access_key_id=settings.S3_ACCESS_KEY,
            aws_secret_access_key=settings.S3_SECRET_KEY,
            region_name=settings.S3_REGION,
            use_ssl=settings.S3_USE_SSL,
            config=Config(signature_version="s3v4"),
        )

    def upload_customer_document(
        self,
        *,
        organisation_id: UUID,
        project_id: UUID,
        document_id: UUID,
        version_number: int,
        original_filename: str,
        content: bytes,
        mime_type: str,
    ) -> StoredObjectInfo:
        ext = validate_file_magic_and_extension(original_filename, content)
        safe_name = sanitize_filename(original_filename)
        sha256_hex = hashlib.sha256(content).hexdigest()
        object_key = (
            f"org/{organisation_id}/projects/{project_id}/documents/{document_id}/"
            f"v{version_number}/{sha256_hex[:16]}_{safe_name}"
        )
        self.client.put_object(
            Bucket=settings.S3_BUCKET_CUSTOMER_DOCS,
            Key=object_key,
            Body=content,
            ContentType=mime_type or "application/octet-stream",
            Metadata={
                "organisation_id": str(organisation_id),
                "sha256": sha256_hex,
            },
        )
        return StoredObjectInfo(
            bucket=settings.S3_BUCKET_CUSTOMER_DOCS,
            object_key=object_key,
            sha256_checksum=sha256_hex,
            file_size_bytes=len(content),
            sanitized_filename=safe_name,
            detected_extension=ext,
        )

    def download_bytes(self, *, bucket: str, object_key: str) -> bytes:
        resp = self.client.get_object(Bucket=bucket, Key=object_key)
        return resp["Body"].read()

    def generate_presigned_download_url(self, *, bucket: str, object_key: str, filename: str, expires_in: int = 900) -> str:
        return self.client.generate_presigned_url(
            "get_object",
            Params={
                "Bucket": bucket,
                "Key": object_key,
                "ResponseContentDisposition": f'attachment; filename="{sanitize_filename(filename)}"',
            },
            ExpiresIn=expires_in,
        )
