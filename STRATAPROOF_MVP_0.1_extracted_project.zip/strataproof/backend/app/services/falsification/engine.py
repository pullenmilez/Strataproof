from datetime import datetime, timezone
from uuid import UUID
from sqlalchemy.orm import Session

from app.core.enums import (
    PetroleumSystemElementType,
    ProcessingStatus,
    QualitativeStatus,
    ReviewStatus,
)
from app.models.knowledge import BasinProfile
from app.models.operational import (
    AnalysisRun,
    ClaimEvidence,
    Contradiction,
    FalsificationHypothesis,
    GeologicalClaim,
    HypothesisEvidence,
    Organisation,
    PetroleumSystemElement,
    Prospect,
)
from app.services.ai.provider import PluggableAIProvider
from app.services.ai.rag import retrieve_verified_basin_knowledge
from app.services.falsification.prioritizer import generate_and_rank_investigations

DEFAULT_FAILURE_MODES = {
    PetroleumSystemElementType.SOURCE_ROCK: (
        "Absence of effective oil- or gas-prone source rock facies or insufficient organic richness (TOC/HI) within the prospect fetch area.",
        "Applicable across clastic and carbonate basins where source-rock lateral continuity is inferred from distant wells.",
    ),
    PetroleumSystemElementType.THERMAL_MATURITY: (
        "Insufficient burial depth or paleo-heat flow to bring source horizons into the hydrocarbon expulsion window.",
        "Critical on basin margins, structural highs, or inverted rift blocks with eroded overburden.",
    ),
    PetroleumSystemElementType.RESERVOIR: (
        "Reservoir pinch-out, diagenetic porosity occlusion, or shale-out across the mapped prospect closure.",
        "Applicable where reservoir presence is extrapolated from seismic amplitude or offset well logs.",
    ),
    PetroleumSystemElementType.SEAL: (
        "Top-seal capillary breakthrough or across-fault sand-on-sand juxtaposition allowing vertical/lateral hydrocarbon leakage.",
        "Critical in fault-bounded traps and stacked deltaic/rift sand-shale sequences.",
    ),
    PetroleumSystemElementType.TRAP: (
        "False structural closure caused by depth-conversion velocity pull-up or unmapped fault compartmentalization.",
        "Applies to all time-migrated seismic closures lacking dense checkshot/VSP velocity calibration.",
    ),
    PetroleumSystemElementType.MIGRATION: (
        "Shadow-zone isolation or lack of continuous carrier beds/fault conduits linking the mature kitchen to the trap.",
        "Applies where structural spill-points or intervening sealing faults divert charge away from the prospect.",
    ),
    PetroleumSystemElementType.TIMING: (
        "Trap-forming faulting or folding post-dated peak hydrocarbon expulsion from the kitchen.",
        "Critical in basins affected by multi-phase tectonic inversion or late growth-fault reactivation.",
    ),
    PetroleumSystemElementType.PRESERVATION: (
        "Post-entrapment tectonic uplift, fault reactivation breach, meteoric flushing, or severe biodegradation.",
        "Applies to shallow reservoirs (<1,500 m) and structurally inverted or reactivated fault blocks.",
    ),
}


def run_petroleum_system_falsification(
    db: Session,
    *,
    prospect: Prospect,
    triggered_by_user_id: UUID,
) -> AnalysisRun:
    org = db.query(Organisation).filter(Organisation.id == prospect.organisation_id).first()
    ai_provider = PluggableAIProvider(org_ai_authorized=bool(org and org.ai_processing_authorized))

    run = AnalysisRun(
        organisation_id=prospect.organisation_id,
        prospect_id=prospect.id,
        run_type="FALSIFICATION_ANALYSIS",
        triggered_by=triggered_by_user_id,
        executed_rule_versions=[{"engine": "petroleum_system_falsification", "version": "v1.0.0"}],
        ai_model_used="deterministic-geological-synthesis-v1" if not ai_provider.is_external_enabled else "configured-llm",
        status=ProcessingStatus.COMPLETED,
    )
    db.add(run)
    db.flush()

    basin_profile = (
        db.query(BasinProfile).filter(BasinProfile.id == prospect.basin_profile_id).first()
        if prospect.basin_profile_id
        else None
    )
    verified_citations = retrieve_verified_basin_knowledge(
        db,
        country=prospect.country,
        basin_name=prospect.basin_name,
        limit=10,
    )

    claims = (
        db.query(GeologicalClaim)
        .filter(
            GeologicalClaim.prospect_id == prospect.id,
            GeologicalClaim.organisation_id == prospect.organisation_id,
            GeologicalClaim.deleted_at.is_(None),
        )
        .all()
    )
    open_contradictions = (
        db.query(Contradiction)
        .filter(
            Contradiction.prospect_id == prospect.id,
            Contradiction.organisation_id == prospect.organisation_id,
            Contradiction.deleted_at.is_(None),
        )
        .all()
    )

    # Clear prior unreviewed hypotheses for clean re-run
    db.query(FalsificationHypothesis).filter(
        FalsificationHypothesis.prospect_id == prospect.id,
        FalsificationHypothesis.organisation_id == prospect.organisation_id,
        FalsificationHypothesis.review_status == ReviewStatus.AI_SUGGESTED_PENDING_REVIEW,
    ).delete(synchronize_session=False)
    db.flush()

    hypotheses_for_ranking: list[tuple[FalsificationHypothesis, PetroleumSystemElementType]] = []

    for elem_type in PetroleumSystemElementType:
        elem_claims = [c for c in claims if c.petroleum_system_element == elem_type]
        supporting_ids: list[UUID] = []
        opposing_ids: list[UUID] = []

        for c in elem_claims:
            for lk in db.query(ClaimEvidence).filter(ClaimEvidence.claim_id == c.id).all():
                if lk.relationship_role == "SUPPORTING":
                    supporting_ids.append(lk.evidence_id)
                elif lk.relationship_role == "OPPOSING":
                    opposing_ids.append(lk.evidence_id)

        elem_contradictions = [ct for ct in open_contradictions if elem_type.value in (ct.well_or_interval or "")]
        missing_items: list[str] = []

        if not elem_claims:
            status_val = QualitativeStatus.INSUFFICIENT_EVIDENCE
            missing_items.append(f"No geological claims registered for {elem_type.value}.")
            rationale = f"Insufficient evidence: zero geological claims or primary records evaluate {elem_type.value}."
        elif opposing_ids and supporting_ids:
            status_val = QualitativeStatus.MIXED_EVIDENCE
            rationale = (
                f"Mixed evidence: {len(supporting_ids)} supporting and {len(opposing_ids)} opposing evidence item(s) "
                f"linked across {len(elem_claims)} claim(s)."
            )
        elif opposing_ids or elem_contradictions:
            status_val = QualitativeStatus.CONTRADICTED
            rationale = (
                f"Contradicted or contested: {len(opposing_ids)} opposing evidence item(s) and "
                f"{len(elem_contradictions)} validation contradiction(s) affect {elem_type.value}."
            )
        elif supporting_ids:
            all_approved = all(c.review_status == ReviewStatus.APPROVED for c in elem_claims)
            status_val = QualitativeStatus.SUPPORTED if all_approved else QualitativeStatus.PARTIALLY_SUPPORTED
            if not all_approved:
                missing_items.append("One or more supporting claims have not yet completed peer review.")
            rationale = (
                f"{status_val.value}: backed by {len(supporting_ids)} linked evidence item(s) across "
                f"{len(elem_claims)} claim(s)."
            )
        else:
            status_val = QualitativeStatus.WEAKLY_SUPPORTED
            missing_items.append(f"Claims exist for {elem_type.value} but lack linked primary EvidenceItems.")
            rationale = f"Weakly supported: {len(elem_claims)} claim(s) stated without linked primary documentary evidence."

        ps_elem = (
            db.query(PetroleumSystemElement)
            .filter(
                PetroleumSystemElement.prospect_id == prospect.id,
                PetroleumSystemElement.element_type == elem_type,
            )
            .first()
        )
        if not ps_elem:
            ps_elem = PetroleumSystemElement(
                organisation_id=prospect.organisation_id,
                prospect_id=prospect.id,
                element_type=elem_type,
                qualitative_status=status_val,
                status_rationale=rationale,
                missing_evidence_summary=missing_items,
            )
            db.add(ps_elem)
            db.flush()
        else:
            ps_elem.qualitative_status = status_val
            ps_elem.status_rationale = rationale
            ps_elem.missing_evidence_summary = missing_items

        base_mechanism, relevance = DEFAULT_FAILURE_MODES[elem_type]
        if basin_profile:
            relevance = f"{relevance} Basin context ({basin_profile.basin_name}): {basin_profile.known_uncertainties_and_gaps}"

        ai_out = ai_provider.synthesize_falsification_narrative(
            system_prompt=(
                "You are a skeptical petroleum exploration geoscientist. State only verifiable geological failure "
                "mechanisms grounded in the supplied evidence. Never invent numbers, depths, or probabilities."
            ),
            user_prompt=f"Prospect: {prospect.name}, Basin: {prospect.basin_name}, Element: {elem_type.value}, Status: {status_val.value}",
            fallback_text=base_mechanism,
        )

        hyp = FalsificationHypothesis(
            organisation_id=prospect.organisation_id,
            prospect_id=prospect.id,
            element_id=ps_elem.id,
            analysis_run_id=run.id,
            proposed_failure_mechanism=ai_out.text,
            geological_applicability=f"{prospect.country} — {prospect.basin_name} ({elem_type.value})",
            relevance_conditions=relevance,
            missing_evidence=missing_items,
            knowledge_source_ids=[str(vc.knowledge_source_id) for vc in verified_citations if vc.knowledge_source_id],
            confidence_rationale=(
                f"Qualitative assessment status is {status_val.value}. "
                f"Grounded in {len(supporting_ids)} supporting, {len(opposing_ids)} opposing prospect evidence items, "
                f"and {len(verified_citations)} verified regional knowledge record(s)."
            ),
            is_ai_suggested=True,
            review_status=ReviewStatus.AI_SUGGESTED_PENDING_REVIEW,
        )
        db.add(hyp)
        db.flush()

        for eid in set(supporting_ids):
            db.add(
                HypothesisEvidence(
                    organisation_id=prospect.organisation_id,
                    hypothesis_id=hyp.id,
                    evidence_id=eid,
                    stance="OPPOSES_FAILURE",
                )
            )
        for eid in set(opposing_ids):
            db.add(
                HypothesisEvidence(
                    organisation_id=prospect.organisation_id,
                    hypothesis_id=hyp.id,
                    evidence_id=eid,
                    stance="SUPPORTS_FAILURE",
                )
            )

        hypotheses_for_ranking.append((hyp, elem_type))

    generate_and_rank_investigations(
        db,
        prospect_id=prospect.id,
        organisation_id=prospect.organisation_id,
        hypotheses_with_elements=hypotheses_for_ranking,
    )

    run.completed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(run)
    return run
