from sqlalchemy.orm import Session
from app.core.enums import PetroleumSystemElementType
from app.models.operational import FalsificationHypothesis, Investigation, InvestigationRanking

ELEMENT_DISCRIMINATION_WEIGHT = {
    PetroleumSystemElementType.TRAP: 100,
    PetroleumSystemElementType.SEAL: 95,
    PetroleumSystemElementType.SOURCE_ROCK: 90,
    PetroleumSystemElementType.THERMAL_MATURITY: 85,
    PetroleumSystemElementType.TIMING: 80,
    PetroleumSystemElementType.MIGRATION: 75,
    PetroleumSystemElementType.RESERVOIR: 70,
    PetroleumSystemElementType.PRESERVATION: 65,
}

INVESTIGATION_TEMPLATES = {
    PetroleumSystemElementType.SOURCE_ROCK: (
        "Source-Rock Organic Geochemistry & TOC/Rock-Eval Audit",
        "Determine whether effective oil- or gas-prone source facies (TOC, HI, kerogen type) exist within the fetch area.",
        "Rock-Eval pyrolysis, Total Organic Carbon (TOC), and maceral/biomarker analysis on ditch cuttings or sidewall cores.",
        "High feasibility using archived cuttings or regional offset well geochemical datasets.",
    ),
    PetroleumSystemElementType.THERMAL_MATURITY: (
        "1D/2D Burial History & Vitrinite Reflectance Calibration",
        "Test whether candidate source horizons entered and remained in the hydrocarbon generation window prior to trap formation.",
        "Vitrinite reflectance (%Ro), Tmax profiles, and corrected bottom-hole temperature (BHT) logs.",
        "High feasibility if offset well logs and temperature surveys are available.",
    ),
    PetroleumSystemElementType.RESERVOIR: (
        "Core / Petrophysical Net-Pay & Facies Continuity Verification",
        "Verify reservoir net-to-gross, effective porosity, permeability, and lateral sand/carbonate continuity across the prospect.",
        "Petrophysical log re-evaluation (GR, RHOB, NPHI, RT), core plug poroperm data, and seismic attribute/AVO calibration.",
        "High feasibility via existing LAS logs and seismic horizon attribute extraction.",
    ),
    PetroleumSystemElementType.SEAL: (
        "Top-Seal Capillary Entry Pressure & Across-Fault SGR Analysis",
        "Test whether top-seal shales and bounding faults can retain the proposed hydrocarbon column without capillary or mechanical breach.",
        "Shale Gouge Ratio (SGR) fault-seal modeling, pressure-depth (RFT/MDT) gradient plots, and caprock lithology logs.",
        "Moderate-to-high feasibility using fault-throw mapping and offset well pressure data.",
    ),
    PetroleumSystemElementType.TRAP: (
        "Depth-Conversion Velocity Sensitivity & Structural Closure Audit",
        "Verify that four-way dip or fault-dependent structural closure persists under plausible depth-conversion velocity models.",
        "Checkshot / VSP time-depth calibration, anisotropic depth migration velocity sensitivity, and fault-plane map audit.",
        "High feasibility prior to drill-decision commitment.",
    ),
    PetroleumSystemElementType.MIGRATION: (
        "Carrier-Bed & Fault-Conduit Migration Pathway Mapping",
        "Determine whether a continuous, geometrically valid migration pathway connects the mature kitchen to the prospect trap.",
        "Top-carrier-bed structural spill-point and fetch-area ray-tracing on depth-converted regional horizons.",
        "Moderate feasibility depending on regional 2D/3D seismic coverage.",
    ),
    PetroleumSystemElementType.TIMING: (
        "Structural Restoration vs. Peak Expulsion Timing Reconstruction",
        "Verify that trap closure existed prior to peak hydrocarbon expulsion from the kitchen.",
        "2D/3D structural flattening/restoration integrated with basin thermal-expulsion history.",
        "Moderate feasibility using interpreted stratigraphic horizons.",
    ),
    PetroleumSystemElementType.PRESERVATION: (
        "Post-Entrapment Uplift, Biodegradation & Fault-Reactivation Check",
        "Assess whether Neogene/Cenozoic uplift, meteoric flushing, biodegradation, or late fault reactivation breached or degraded hydrocarbons.",
        "Reservoir temperature/salinity screening, fluid-inclusion/oil-API offset comparison, and shallow seismic gas-chimney inspection.",
        "High feasibility using seismic amplitude anomalies and regional offset fluid properties.",
    ),
}


def generate_and_rank_investigations(
    db: Session,
    *,
    prospect_id,
    organisation_id,
    hypotheses_with_elements: list[tuple[FalsificationHypothesis, PetroleumSystemElementType]],
) -> list[Investigation]:
    # Clear existing unranked/prior investigations for clean regeneration
    db.query(Investigation).filter(
        Investigation.prospect_id == prospect_id,
        Investigation.organisation_id == organisation_id,
    ).delete(synchronize_session=False)
    db.flush()

    scored: list[tuple[int, FalsificationHypothesis, PetroleumSystemElementType]] = []
    for hyp, elem_type in hypotheses_with_elements:
        base_score = ELEMENT_DISCRIMINATION_WEIGHT.get(elem_type, 50)
        gap_bonus = min(len(hyp.missing_evidence) * 4, 20)
        scored.append((base_score + gap_bonus, hyp, elem_type))

    scored.sort(key=lambda x: x[0], reverse=True)

    created_investigations: list[Investigation] = []
    for rank_idx, (score, hyp, elem_type) in enumerate(scored, start=1):
        title, obj, req_test, feasibility = INVESTIGATION_TEMPLATES[elem_type]
        inv = Investigation(
            organisation_id=organisation_id,
            prospect_id=prospect_id,
            hypothesis_id=hyp.id,
            title=title,
            discriminating_objective=obj,
            required_data_or_test=req_test,
            user_supplied_cost_estimate=None,
            user_supplied_time_estimate=None,
            technical_feasibility_note=feasibility,
        )
        db.add(inv)
        db.flush()

        decision_rel = "CRITICAL" if rank_idx <= 3 else ("HIGH" if rank_idx <= 6 else "MODERATE")
        db.add(
            InvestigationRanking(
                organisation_id=organisation_id,
                investigation_id=inv.id,
                priority_rank=rank_idx,
                decision_relevance=decision_rel,
                discrimination_power=f"Directly tests {elem_type.value} failure hypothesis (Rank #{rank_idx})",
                prioritisation_rationale=(
                    f"Ranked #{rank_idx} based on structural/petroleum-system criticality of {elem_type.value} "
                    f"and {len(hyp.missing_evidence)} unresolved evidence gap(s). Cost and duration remain user-supplied."
                ),
            )
        )
        created_investigations.append(inv)

    return created_investigations
