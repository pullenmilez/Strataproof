# STRATAPROOF — MVP 0.1
**Petroleum Exploration Geological Evidence-Assurance & Falsification Platform**

## Overview
STRATAPROOF is an enterprise subsurface assurance system designed to evaluate exploration prospects by answering:
> *"What could make this exploration prospect fail, what evidence supports or contradicts the geological interpretation, what information is missing, and what investigation could help resolve the most important uncertainty?"*

### Core Architectural Guarantees
- **Three Segregated Data Environments:**
  - **Environment A:** Customer Raw & Processed Files in private S3/MinIO storage (`SHA-256` checksummed, short-lived presigned URLs).
  - **Environment B:** Curated & Verified Geological Knowledge Library seeded with all 14 Nigerian sedimentary basins and strict `APPROVED` retrieval gating.
  - **Environment C:** Multi-Tenant Operational & Audit Database protected by PostgreSQL Row-Level Security (`app.current_organisation_id`) and RBAC.
- **No Fabricated Facts or Probabilities:** Missing evidence is explicitly surfaced as `INSUFFICIENT_EVIDENCE` or `REQUIRES_HUMAN_CHECK`. No discovery probabilities or invented numbers are ever generated.

## Quick Start (Local Development)
1. **Start Infrastructure Services (PostgreSQL 16 + pgvector, Redis, MinIO):**
   ```bash
   cp .env.example .env
   docker compose -f infra/docker-compose.yml up -d
   ```
2. **Install Backend Dependencies & Run Migrations:**
   ```bash
   cd backend
   python -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   alembic upgrade head
   ```
3. **Run FastAPI Server & Celery Ingestion Worker:**
   ```bash
   uvicorn app.main:app --reload --port 8000
   celery -A app.worker.celery_app.celery_app worker --loglevel=info
   ```
4. **Run Automated Verification Tests:**
   ```bash
   cd backend
   pytest -v
   ```
5. **Run Next.js Frontend Workspace:**
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
